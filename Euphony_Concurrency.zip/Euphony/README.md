# Euphony.com

This would be a retail website for selling musical instruments. 

There will be two types of users i.e. Buyers and Administrators

The website called Euphony.com, will allow Buyers to view the available products from the inventory. Buyers will be able to search for products using a search feature on the website. From the list, the buyer can select a desired item to view its details. If interested in buying the product, they can add it to the cart and complete the purchase process. 

Buyers can register with the website by entering their personal details. 
To make purchases, they need to add their credit card details. 

There will be an Admin section for the Administrator users. This will be used to add products to the system and manage all the users. 

Currently the website sells only basic Acoustic and Electric Guitars, Keyboards and related accessories. 

There will be a Reports section using which the Admin users will be able to retrieve the User IDs and other details about users from the system. Similarly, users can retrieve a list of the Product data.

The system will allow users to get some more specific data like most expensive product, total stock, total cost of stock, distinct brands and models in the stock etc. using the Reports section.

The system will allow users to take a backup of the product and user data and view it if required. 

The Product and User data will now get added to a database instead of a CSV file.

Users can generate new reports using data in the database.

They will be able to run the following reports and generate a CSV file containing the same details –
- Get all Products from the database
    - Using this the user can view all the details for all the Products in the database.
- Get all Users from the database
    - Using this the user can view all the details for all the Products in the database.
- Get all Orders from the database
    - Using this report the user can view all the details for all the Orders in the database.
- Get details for a single order
    - Using this the user can view the details of a single order from the list of orders provided.



## Getting Started
- Unzip the <Project_Assignment>.zip file.
- Using IntelliJ IDEA IDE, select File -> Open and select the Euphony directory that was unzipped from the zip file.
- Before running the Main file/Application the second time, 
please note that the you need to uncomment lines 36 and 37 from the Main.java file to avoid seeing the exceptions.
- Run the Main.java file and respond with inputs based on the request made by the program.
- When a backup is created, the system generates the backup files in a .dat format in the root directory


#### Important Directories
- The 'Euphony/src/com/Euphony/backup' directory contains the code related to backing-up and viewing the backed-up data
- The 'Euphony/src/com/Euphony/dataio' directory contains the code related to adding a product to the system. 
It has two separate folders for separating the database and CSV file data I/O
- The 'Euphony/src/com/Euphony/exceptions' directory contains the user defined exception
- The 'Euphony/src/com/Euphony/javaFxDemoOnly' directory contains the code showing the usage of JavaFX.
- The 'Euphony/src/com/Euphony/product' directory contains the code related to adding a product to the system
- The 'Euphony/src/com/Euphony/users' directory contains the code related to adding users to the system
- The 'Euphony/src/com/Euphony/reports' directory contains the code to generate reports. 
It has two separate folders for separating the implementations for database and CSV Reports.
- The 'Euphony/DatabaseReports' directory contains the CSV file Reports generated from the Database
- The 'Euphony/data' directory contains the CSV files that store the User and Product related data


## Unit Tests
- The 'Euphony/src/tests directory contains the JUnit tests written for this project.
- It also contains the CSV file used by the TestDataReader tests.
- Please delete the lines that get added to the CSV files once the test runs are complete
  (To Do - Workaround)

## Version
5.0 (Assignment 5)


## Authors
- Elden Wicks | ewicks@bu.edu


## Acknowledgments
- Ed Orsini | edorsini@bu.edu
