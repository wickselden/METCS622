/**
 * CS-622
 * TestAddProduct.java
 * Purpose: This is used for testing the add product functionality.
 * This test will assert the return statements from AcousticGuitar, ElectricGuitar and Keyboard classes.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.product.AcousticGuitar;
import com.Euphony.product.ElectricGuitar;
import com.Euphony.product.Keyboard;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestAddProduct {

  @Test // Testing the addition of an Acoustic Guitar
  public void addProductAcousticGuitarTest() {
    AcousticGuitar acGuitar = new AcousticGuitar(1001, "Gibson", "G-1001", 400, 6, 12,
        "RightHanded", "Mahogany", "Best guitar under $500",
        "TM  One", "Fibreglass");
    assertEquals("Product details are - \n" +
            "Item number - 1001, \n" +
            "Brand - Gibson, \n" +
            "Model - G-1001, \n" +
            "Price - 400.00, \n" +
            "Num of Strings - 6, \n" +
            "Stock - 12, \n" +
            "Orientation - RightHanded, \n" +
            "Body Type - Mahogany, \n" +
            "Guitar Details - Best guitar under $500, \n" +
            "Top Material - TM  One, \n" +
            "Back & Side Material - Fibreglass\n",
        acGuitar.addProduct(1001, "Gibson", "G-1001", 400, 6, 12,
            "RightHanded", "Mahogany", "Best guitar under $500",
            "TM  One", "Fibreglass"));
  }

  @Test // Testing the addition of an Electric Guitar
  public void addProductElectricGuitarTest() {
    ElectricGuitar elecGuitar = new ElectricGuitar(2001, "Fender", "F-1001", 900, 6, 21,
        "RightHanded", "Mahogany", "Best guitar under $1,000",
        "Smooth", "PinHole Config");
    assertEquals("Product details are - \n" +
            "Item number - 2001, \n" +
            "Brand - Fender, \n" +
            "Model - F-1001, \n" +
            "Price - 900.00, \n" +
            "Num of Strings - 6, \n" +
            "Stock - 21, \n" +
            "Orientation - RightHanded, \n" +
            "Body Type - Mahogany, \n" +
            "Guitar Details - Best guitar under $1,000, \n" +
            "Bridge Type - Smooth, \n" +
            "Pickup Config - PinHole Config\n",
        elecGuitar.addProduct(2001, "Fender", "F-1001", 900, 6, 21,
            "RightHanded", "Mahogany", "Best guitar under $1,000",
            "Smooth", "PinHole Config"));
  }

  @Test // Testing the addition of a Keyboard
  public void addProductKeyboardTest() {
    Keyboard keyboard = new Keyboard(3001, "Casio", "CDP-130", 299, 10);
    assertEquals("Product details are - \n" +
            "Item number - 3001, \n" +
            "Brand - Casio, \n" +
            "Model - CDP-130, \n" +
            "Price - 299.00, \n" +
            "Num of Keys - 88, \n" +
            "Stock - 10",
        keyboard.addProduct(3001, "Casio", "CDP-130", 299, 88, 10));
  }
}