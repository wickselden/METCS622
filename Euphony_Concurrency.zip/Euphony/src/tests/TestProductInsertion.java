/**
 * CS-622
 * TestProductInsertion.java
 * Purpose: This is used for testing if the insertion of a Product in to the Products table.
 * The test inserts a Product and verifies if the data has been inserted by running a Select statement
 * on the newly added Product and verifying if the result set size is equal to 1
 * The test also deletes the Product after verification by running a Delete statement
 * on the newly added Product and then runs a Select statement again to
 * verify if the result set size is equal to 0
 *
 * @author Elden Wicks
 */

package tests;

import org.junit.Test;

import java.sql.*;

public class TestProductInsertion {

  @Test // Test Products Insertion
  public void testInsertIntoProducts() throws Exception {
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Insert Into
    System.out.println("Running Insert Into Products\n");

    String query1 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (51, 50001, 'TestData', 'TD-1001', 1200, 5, 10,'RH', 'TestRosewood', 'This is a Test guitar', 'Test', 'Fibreglass') ";

    // Run Insert query
    try {
      stmt.execute(query1);
      System.out.println("Done Inserting Test Data Into Products\n");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Run Select query
    String query2 = "SELECT * FROM Products WHERE Id = 51";
    ResultSet rs = stmt.executeQuery(query2);

    // Display output of resultset
    while (rs.next()) {
      System.out.println(rs.getString(1) + ", " +
          rs.getString(2) + ", " +
          rs.getString(3) + ", " +
          rs.getString(4) + ", " +
          rs.getString(5) + ", " +
          rs.getString(6) + ", " +
          rs.getString(7) + ", " +
          rs.getString(8) + ", " +
          rs.getString(9) + ", " +
          rs.getString(10) + ", " +
          rs.getString(11) + ", " +
          rs.getString(12)
      );
    }

    ResultSet rs1 = stmt.executeQuery(query2);

    // Verify if Result has 1 row
    int rs1_size=0;
    while (rs1.next()) {
      rs1_size++;
    }
    assert rs1_size == 1;

    // Delete the test Product
    System.out.println("--------------------------\n");
    System.out.println("Running Delete from Products\n");

    String query3 = "DELETE FROM Products WHERE Id = 51";

    // Run Delete query
    try {
      stmt.execute(query3);
      System.out.println("Done Deleting Data From Products");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Run Select query
    String query4 = "SELECT * FROM Products WHERE Id = 51";
    ResultSet rs2 = stmt.executeQuery(query4);

    // Verify if Result has 0 rows
    int rs2_size=0;
    while (rs2.next()) {
      rs2_size++;
    }

    // Assert if Result has 0 rows
    assert rs2_size == 0;
    System.out.println("There are 0 records matching the Product Id");
  }
}