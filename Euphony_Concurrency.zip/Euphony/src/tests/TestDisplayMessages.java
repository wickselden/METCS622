/**
 * CS-622
 * TestDisplayMessages.java
 * Purpose: This is used for testing the success messages returned by the classes using Polymorphism.
 * This test will assert the AcousticGuitar, ElectricGuitar and Keyboard classes return the appropriate messages.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.product.AcousticGuitar;
import com.Euphony.product.ElectricGuitar;
import com.Euphony.product.Keyboard;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDisplayMessages {

  @Test // Testing the success message source for Acoustic Guitar
  public void acousticGuitarSuccessMessageTest() {
    AcousticGuitar ag1 = new AcousticGuitar(1001, "Gibson", "G-1001", 400, 5, 6,
        "RightHanded", "Mahogany", "Best guitar under $500", "TM  One", "Fibreglass");
    assertEquals("\nAcoustic Guitar has been added!", ag1.displaySuccessMessage());
  }

  @Test // Testing the success message source for Electric Guitar
  public void electricGuitarSuccessMessageTest() {
    ElectricGuitar eg1 = new ElectricGuitar(2001, "Fender", "F-1001", 900, 3, 5,
        "RightHanded", "Mahogany", "Best guitar under $1,000", "Smooth", "PinHole Config");
    assertEquals("\nElectric Guitar has been added!", eg1.displaySuccessMessage());
  }

  @Test // Testing the success message source for Keyboard
  public void keyboardSuccessMessageTest() {
    Keyboard kb1 = new Keyboard(3001, "Casio", "CDP-130", 299, 10);
    assertEquals("\nKeyboard has been added!", kb1.displaySuccessMessage());
  }
}