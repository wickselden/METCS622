/**
 * CS-622
 * TestDbReportGeneration.java
 * Purpose: This is used for testing if the database reports are getting generated.
 * The test calls the methods for generating the Users, Products and Orders Reports
 * and verifies if the filename returned from those methods exists in the system.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.reports.dbReports.OrdersDbReports;
import com.Euphony.reports.dbReports.UserAndProductDbReports;
import org.junit.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestDbReportGeneration {

  @Test // Test Products Report
  public void testProductsReport() throws ClassNotFoundException {
    File file = new File(UserAndProductDbReports.getUserAndProductDbReport("ProductsReport"));
    System.out.println("File Created -> " + file);
    assertTrue(file.exists());
    System.out.println("File exists!");
  }

  @Test // Test Users Report
  public void testUsersReport() throws ClassNotFoundException {
    File file = new File(UserAndProductDbReports.getUserAndProductDbReport("UsersReport"));
    System.out.println("File Created -> " + file);
    assertTrue(file.exists());
    System.out.println("File exists!");
  }

  @Test // Test All Orders Report
  public void testAllOrdersReport() throws ClassNotFoundException {
    File file = new File(OrdersDbReports.getAllOrdersDbReport());
    System.out.println("File Created -> " + file);
    assertTrue(file.exists());
    System.out.println("File exists!");
  }

}