/**
 * CS-622
 * TestUserInsertion.java
 * Purpose: This is used for testing if the insertion of a User in to the Users table.
 * The test inserts a user and verifies if the data has been inserted by running a Select statement
 * on the newly added User and verifying if the result set size is equal to 1
 * The test also deletes the User after verification by running a Delete statement
 * on the newly added User and then runs a Select statement again to
 * verify if the result set size is equal to 0
 *
 * @author Elden Wicks
 */

package tests;

import org.junit.Test;

import java.sql.*;

public class TestUserInsertion {

  @Test // Test User Insertion
  public void testInsertIntoProducts() throws Exception {
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Insert Into
    System.out.println("Running Insert Into Users\n");

    String query1 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (52,'Admin','Test','User','eldenwicks','TestPwd','6462900888','2/2/2020','Administrator') ";

    // Run Insert query
    try {
      stmt.execute(query1);
      System.out.println("Done Inserting Test Data Into Users\n");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Run Select query
    String query2 = "SELECT * FROM Users WHERE Id = 52";
    ResultSet rs = stmt.executeQuery(query2);

    // Display output of resultset
    while (rs.next()) {
      System.out.println(rs.getString(1) + ", " +
          rs.getString(2) + ", " +
          rs.getString(3) + ", " +
          rs.getString(4) + ", " +
          rs.getString(5) + ", " +
          rs.getString(6) + ", " +
          rs.getString(7) + ", " +
          rs.getString(8) + ", " +
          rs.getString(9)
      );
    }

    ResultSet rs1 = stmt.executeQuery(query2);

    // Verify if Result has 1 row
    int rs1_size = 0;
    while (rs1.next()) {
      rs1_size++;
    }
    assert rs1_size == 1;

    // Delete the test User
    System.out.println("--------------------------\n");
    System.out.println("Running Delete from Products\n");

    String query3 = "DELETE FROM Users WHERE Id = 52";

    // Run Delete query
    try {
      stmt.execute(query3);
      System.out.println("Done Deleting Test Record From Users");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Run Select query
    String query4 = "SELECT * FROM Users WHERE Id = 52";
    ResultSet rs2 = stmt.executeQuery(query4);

    // Verify if Result has 0 rows
    int rs2_size = 0;
    while (rs2.next()) {
      rs2_size++;
    }

    // Assert if Result has 0 rows
    assert rs2_size == 0;
    System.out.println("There are 0 records matching the User Id");

  }
}