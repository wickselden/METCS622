/**
 * CS-622
 * TestDataWriter.java
 * Purpose: This is used for testing the DataWriter class' functionality.
 * This test will assert the class writes the required data to the CSV file.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.dataio.csvFiles.DataWriter;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDataWriter {

  @Test // Testing data writer for Add Product
  public void testDataWriterProduct() {
    DataWriter dw = new DataWriter();
    assertEquals("[NOTE:, This, is, JUnit, testdata, 0, and, has, to, be, deleted]",
        dw.dataWriter("[NOTE:, This, is, JUnit, testdata, 0, and, has, to, be, deleted]", "Product"));
    System.out.println(("\nNOTE: Please delete the above line from the product_data.csv " +
        "file after tests are complete.\n").toUpperCase());
  }

  @Test // Testing data writer for Add User
  public void testDataWriterUser() {
    DataWriter dw = new DataWriter();
    assertEquals("[NOTE:, This, is, JUnit, testdata, 0, and, has, to, be, deleted]",
        dw.dataWriter("[NOTE:, This, is, JUnit, testdata, 0, and, has, to, be, deleted]", "User"));
    System.out.println(("\nNOTE: Please delete the above line from the user_data.csv " +
        "file after tests are complete.\n").toUpperCase());
  }
}