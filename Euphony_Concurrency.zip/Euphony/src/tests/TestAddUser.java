/**
 * CS-622
 * TestAddUser.java
 * Purpose: This is used for testing the add user functionality.
 * This test will assert the return statements from Administrator and Buyer classes.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.users.Administrator;
import com.Euphony.users.Buyer;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestAddUser {

  @Test // Testing the addition of an Administrator
  public void addAdministratorTest() {
    Administrator admin = new Administrator("Admin", "Elden", "Wicks", "eldenwicks", "myPassword",
        "6462900844", "02/02/2020", "Manager");
    assertEquals("Administrator details are - \n" +
            "Type - Admin, \n" +
            "First Name - Elden, \n" +
            "Last Name - Wicks, \n" +
            "Username - eldenwicks, \n" +
            "Password - myPassword, \n" +
            "Phone Number - 6462900844, \n" +
            "Date of Joining - 02/02/2020, \n" +
            "Designation - Manager\n",
        admin.addUser("Admin", "Elden", "Wicks", "eldenwicks", "myPassword",
            "6462900844", "02/02/2020", "Manager"));
  }

  @Test // Testing the addition of a Buyer
  public void addBuyerTest() {
    Buyer buyer = new Buyer("Buyer", "Ryan", "Wicks", "ryanwicks", "hisPassword",
        "ryanwicks@gmail.com", "75 Page Rd Unit 1", null);
    assertEquals("Buyer details are - \n" +
            "Type - Buyer, \n" +
            "First Name - Ryan, \n" +
            "Last Name - Wicks, \n" +
            "Username - ryanwicks, \n" +
            "Password - hisPassword, \n" +
            "Email ID - ryanwicks@gmail.com, \n" +
            "Address - 75 Page Rd Unit 1, \n" +
            "Orders - null\n",
        buyer.addUser("Buyer", "Ryan", "Wicks", "ryanwicks", "hisPassword",
            "ryanwicks@gmail.com", "75 Page Rd Unit 1", null));
  }
}