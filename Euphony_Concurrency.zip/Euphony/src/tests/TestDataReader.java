/**
 * CS-622
 * TestDataReader.java
 * Purpose: This is used for testing the DataReader class' functionality.
 * This test will assert the return statements from methods for reading Integer data and String data.
 *
 * @author Elden Wicks
 */

package tests;

import com.Euphony.dataio.csvFiles.DataReader;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDataReader {

  @Test // Test reading User IDs
  public void testUserIdReader() {
    DataReader dataReader = new DataReader();
    assertEquals("[1225433441, 1225457751, 1226448937, 1226862445, 1226867262]",
        Arrays.toString(dataReader.readIntData("./src/tests/test_user_data.csv", 0)));
  }

  @Test // Test reading Usernames
  public void testDataReader() {
    DataReader dataReader = new DataReader();
    assertEquals("[eldenwicksA, rjude, dchauhan, kkhan, johndoe]",
        Arrays.toString(dataReader.readStringData("./src/tests/test_user_data.csv", 4)));
  }
}