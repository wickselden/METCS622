/**
 * CS-622
 * Main.java
 * Purpose: This is the Main class, which is used for running this program.
 * It provides the user with the initial action that a user would like to perform
 * and then makes the required calls to classes that contain the required implementations.
 * Validation is also done for catching incorrect number entered by the user as well as
 * when the user enters a non-integer.
 * The DbDataWriter adds the data entered here into the Products or Users table in the database.
 * If the user selects Reports, then then PickWhichReports class is called.
 * If the user selects Backup Management, then then BackupActions class is called.
 * The user can exit the application by entering 0.
 *
 * @author Elden Wicks
 */

import com.Euphony.backup.BackupActions;
import com.Euphony.dataio.database.DatabaseCreation;
import com.Euphony.dataio.database.DbDataWriter;
import com.Euphony.exceptions.ValidateWithinOptions;
import com.Euphony.product.AddProductWithUserInputs;
import com.Euphony.reports.csvReports.PickWhichReport;
import com.Euphony.users.AddUserWithUserInputs;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

  public static void main(String[] args) throws Exception {

////////////////////////////////////////////////////////////////////////////////////////////////

  // Please uncomment after first run
  // This will take care of creating a database, tables and inserting data into them
    DatabaseCreation databaseCreation = new DatabaseCreation();
    databaseCreation.createDatabase();
////////////////////////////////////////////////////////////////////////////////////////////////


    System.out.println("█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█");
    System.out.println("§  Welcome to Euphony  §".toUpperCase());
    System.out.println("█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█");

    while (true) {

      AddProductWithUserInputs addProd = new AddProductWithUserInputs();
      AddUserWithUserInputs addUser = new AddUserWithUserInputs();
      DbDataWriter dbDataWriter = new DbDataWriter();

//    Scanner for capturing user input
      Scanner user_input_digits = new Scanner(System.in);

      System.out.println("\nWhat would you like to do today?".toUpperCase());
      System.out.println("1. Add Product\n" +
          "2. Add User\n" +
          "3. Delete User (Not Implemented)\n" +
          "4. Run Reports\n" +
          "5. Backup Management\n" +
          "0. Quit\n");

      try {                 // Try catch for incorrect selection made by user
        int task_num = user_input_digits.nextInt();

        if (task_num == 0)   // Exit the application
          return;

        if (task_num == 1)  // Provide the argument as Product to invoke Product Addition
          dbDataWriter.dbDataWriter(addProd.collectUserInput(), "Product");

        if (task_num == 2)  // Provide the argument as User to invoke User Addition
          dbDataWriter.dbDataWriter(addUser.collectUserInput(), "User");

        if (task_num == 3) // TO DO - Showing appropriate message for now
          System.out.println("\nApologies. This feature has not been implemented yet.\n");

        if (task_num == 4)  //Call PickWhichReport to ask the user to pick the data on which reporting is needed
          PickWhichReport.pickWhichReport();

        if (task_num == 5)  //Call Backup Management options
          BackupActions.pickBackupAction();

        if (task_num < 0 || task_num > 5) { // Call the user defined exception if selection is not from the listed numbers
          throw new ValidateWithinOptions("Selection has to be between 1, 2, 3, 4, 5 or 0");
        }
      } catch (ValidateWithinOptions v) {
        System.out.println(v.toString());
      } catch (InputMismatchException e) {  //Show this message when the user does not enter a number
        System.out.println("\nInput Mismatch Error says - Please enter a valid positive number");
      }
    }
  }
}