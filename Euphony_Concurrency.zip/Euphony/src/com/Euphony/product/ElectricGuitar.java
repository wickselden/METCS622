/**
 * CS-622
 * ElectricGuitar.java
 * Purpose: This class extends the Guitar class and is used for adding an Electric Guitar.
 * It is also used for displaying a message once an Electric Guitar has been added (Polymorphism)
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

public class ElectricGuitar extends Guitar {

  public ElectricGuitar(int itemNumber, String brand, String model, float price, int numOfStrings, int stockInHand, String orientation, String bodyType, String guitarDetails, String attribute1, String attribute2) {
    super(itemNumber, brand, model, price, stockInHand);
  }

  @Override
  public void addProduct() {
    System.out.println("Adding Electric Guitar");
  }

  public String addProduct(int itemNumber, String brand, String model, float price, int numOfStrings,
                           int stockInHand, String orientation, String bodyType, String guitarDetails,
                           String bridgeType, String pConfig) {

    String message = String.format("Product details are - \n" +
            "Item number - %d, \nBrand - %s, \nModel - %s, \nPrice - %.2f, \nNum of Strings - %d, \nStock - %d, " +
            "\nOrientation - %s, \nBody Type - %s, \nGuitar Details - %s, \nBridge Type - %s, \nPickup Config - %s\n",
        itemNumber, brand, model, price, numOfStrings, stockInHand,
        orientation, bodyType, guitarDetails, bridgeType, pConfig);

    System.out.println(message);

    displaySuccessMessage();

    return message;
  }

  public String displaySuccessMessage() {
    String message = ("\nElectric Guitar has been added!");
    System.out.println(message);
    return (message);
  }
}