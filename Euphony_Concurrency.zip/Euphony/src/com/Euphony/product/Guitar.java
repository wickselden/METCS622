/**
 * CS-622
 * Guitar.java
 * Purpose: This class extends the Product class and is the parent of the ElectricGuitar and AcousticGuitar classes.
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

public class Guitar extends Product {

  public Guitar(int itemNumber, String brand, String model, float price, int stockInHand) {
    super(itemNumber, brand, model, price, stockInHand);
  }

  @Override
  public void addProduct() {
    System.out.println("Adding Acoustic Guitar");
  }

  public String addProduct(int itemNumber, String brand, String model, float price, int stockInHand,
                           int numOfStrings, String orientation, String bodyType, String guitarDetails,
                           String attribute1, String attribute2) {

    System.out.println("\n\nAdding Guitar...\n");

    String message = String.format("Product details are - \n" +
            "Item number - %d, \nBrand - %s \nModel - %s, \nPrice - %.2f, \nStock - %d, \nNum of Strings - %d, " +
            "\nOrientation - %s, \nBody Type - %s, \nGuitar Details - %s, \nTop Material - %s, \nBack & Side Material - %s\n",
        itemNumber, brand, model, price, stockInHand, numOfStrings,
        orientation, bodyType, guitarDetails, attribute1, attribute2);

    System.out.println(message);

    displaySuccessMessage();

    return message;

  }

  public String displaySuccessMessage() {
    String message = ("\nGuitar has been added!");
    System.out.println(message);
    return (message);
  }

}