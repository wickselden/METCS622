/**
 * CS-622
 * AcousticGuitar.java
 * Purpose: This class extends the Guitar class and is used for adding an Acoustic Guitar.
 * It is also used for displaying a message once an Acoustic Guitar has been added (Polymorphism)
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

public class AcousticGuitar extends Guitar {

  public AcousticGuitar(int itemNumber, String brand, String model, float price, int numOfStrings, int stockInHand, String orientation, String bodyType, String guitarDetails, String attribute1, String attribute2) {
    super(itemNumber, brand, model, price, stockInHand);
  }

  @Override
  public void addProduct() {
    System.out.println("Adding Acoustic Guitar");
  }

  public String addProduct(int itemNumber, String brand, String model, float price, int numOfStrings,
                           int stockInHand, String orientation, String bodyType, String guitarDetails,
                           String topMaterial, String backAndSideMaterial) {

    String message = String.format("Product details are - \n" +
            "Item number - %d, \nBrand - %s, \nModel - %s, \nPrice - %.2f, \nNum of Strings - %d, \nStock - %d, " +
            "\nOrientation - %s, \nBody Type - %s, \nGuitar Details - %s, \nTop Material - %s, \nBack & Side Material - %s\n",
        itemNumber, brand, model, price, numOfStrings, stockInHand, orientation,
        bodyType, guitarDetails, topMaterial, backAndSideMaterial);

    System.out.println(message);

    displaySuccessMessage();

    return message;

  }

  public String displaySuccessMessage() {
    String message = ("\nAcoustic Guitar has been added!");
    System.out.println(message);
    return (message);
  }

}