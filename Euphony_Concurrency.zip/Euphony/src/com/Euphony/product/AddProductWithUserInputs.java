/**
 * CS-622
 * AddProductWithUserInputs.java
 * Purpose: This class is used for requesting Product data as input from the user.
 * This class displays the options for what Product is to be added and
 * asks the user to enter the details for the desired product.
 * After this it invokes the addProduct method for displaying the appropriate message.
 * The same data input by the user is sent back to the DbDataWriter class (called from Main)
 * and this data is written to the Products table.
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

import java.util.ArrayList;
import java.util.Scanner;


//This class takes the input from the users and adds the product to the csv file.
public class AddProductWithUserInputs {

  public String collectUserInput() {

    // Created 2 scanner instances to capture String and int inputs as the scanner was the
    // newline after a string entered by the user as the next response
    Scanner user_input_text = new Scanner(System.in);
    Scanner user_input_digits = new Scanner(System.in);

    // ArrayLists for collecting the data from users
    ArrayList productDetails = new ArrayList();

    String message = ("\nPlease enter the following details".toUpperCase());

    while (true) {

      System.out.println("Please select the product you would like to add using the numbers 1,2 and 3:");
      System.out.println("1. Acoustic Guitar\n" +
          "2. Electric Guitar\n" +
          "3. Keyboard\n");

      int user_entry = user_input_digits.nextInt();

      if (user_entry == 1) {
        System.out.println(message);
        try {
          System.out.println("\nPlease enter an Item Number (e.g. 1001) :");
          int itemNumber = user_input_digits.nextInt();
          productDetails.add(itemNumber);

          System.out.println("\nPlease enter the Brand (e.g. Gibson) :");
          String brand = user_input_text.nextLine();
          productDetails.add(brand);

          System.out.println("\nPlease enter the Model (e.g. G-1001) :");
          String model = user_input_text.nextLine();
          productDetails.add(model);

          System.out.println("\nPlease enter a Price (e.g. 400) :");
          float price = user_input_digits.nextFloat();
          productDetails.add(price);

          System.out.println("\nPlease enter an Number of Strings (e.g. 6) :");
          int numOfStrings = user_input_digits.nextInt();
          productDetails.add(numOfStrings);

          System.out.println("\nPlease enter the Stock in Hand (e.g. 5) :");
          int stock = user_input_digits.nextInt();
          productDetails.add(stock);

          System.out.println("\nPlease enter the Guitar's Orientation (e.g. RH or LH) :");
          String orientation = user_input_text.nextLine();
          productDetails.add(orientation);

          System.out.println("\nPlease enter the Guitar's Body Type (e.g. Rosewood) :");
          String bodyType = user_input_text.nextLine();
          productDetails.add(bodyType);

          System.out.println("\nPlease enter some Guitar Details (e.g. This is a good guitar) :");
          String guitarDetails = user_input_text.nextLine();
          productDetails.add(guitarDetails);

          System.out.println("\nPlease enter the Top Material (e.g. Maple) :");
          String topMat = user_input_text.nextLine();
          productDetails.add(topMat);

          System.out.println("\nPlease enter the Back & Side Material (e.g. Fibreglass) :");
          String backAndSideMat = user_input_text.nextLine();
          productDetails.add(backAndSideMat);

          System.out.println("Thank you for all the details");

          // As the user selected 1, initialize AcousticGuitar and then call the addProduct method
          AcousticGuitar ag1 = new AcousticGuitar(itemNumber, brand, model, price, numOfStrings, stock, orientation, bodyType, guitarDetails, topMat, backAndSideMat);

          ag1.addProduct(itemNumber, brand, model, price, numOfStrings, stock, orientation, bodyType, guitarDetails, topMat, backAndSideMat);

          // Exception handling for input mismatch

        } catch (Exception e) {
          {
            productDetails.clear(); // Clearing the array on incorrect input to make sure incomplete data is not added.
            System.out.println("\nINCORRECT DATA ENTERED!!! Please restart\n\n");
          }
        }
        return productDetails.toString();
      } else if (user_entry == 2) {
        System.out.println(message);
        try {
          System.out.println("\nPlease enter an Item Number (e.g. 2001) :");
          int itemNumber = user_input_digits.nextInt();
          productDetails.add(itemNumber);

          System.out.println("\nPlease enter the Brand (e.g. Fender) :");
          String brand = user_input_text.nextLine();
          productDetails.add(brand);

          System.out.println("\nPlease enter the Model (e.g. F-2001) :");
          String model = user_input_text.nextLine();
          productDetails.add(model);

          System.out.println("\nPlease enter a Price (e.g. 900) :");
          float price = user_input_digits.nextFloat();
          productDetails.add(price);

          System.out.println("\nPlease enter the Stock in Hand (e.g. 25) :");
          int stock = user_input_digits.nextInt();
          productDetails.add(stock);

          System.out.println("\nPlease enter an Number of Strings (e.g. 5) :");
          int numOfStrings = user_input_digits.nextInt();
          productDetails.add(numOfStrings);

          System.out.println("\nPlease enter the Guitar's Orientation (e.g. RH or LH) :");
          String orientation = user_input_text.nextLine();
          productDetails.add(orientation);

          System.out.println("\nPlease enter the Guitar's Body Type (e.g. Aluminum) :");
          String bodyType = user_input_text.nextLine();
          productDetails.add(bodyType);

          System.out.println("\nPlease enter some Guitar Details (e.g. This is a good guitar) :");
          String guitarDetails = user_input_text.nextLine();
          productDetails.add(guitarDetails);

          System.out.println("\nPlease enter the Bridge Type (e.g. Stainless Steel) :");
          String bridgeType = user_input_text.nextLine();
          productDetails.add(bridgeType);

          System.out.println("\nPlease enter the Player Config (e.g. Basic / Advanced) :");
          String pConfig = user_input_text.nextLine();
          productDetails.add(pConfig);

          System.out.println("Thank you for all the details");

          // As the user selected 2, initialize ElectricGuitar and then call the addProduct method
          ElectricGuitar eg1 = new ElectricGuitar(itemNumber, brand, model, price, numOfStrings, stock, orientation, bodyType, guitarDetails, bridgeType, pConfig);

          eg1.addProduct(itemNumber, brand, model, price, numOfStrings, stock, orientation, bodyType, guitarDetails, bridgeType, pConfig);

        }
        // Exception handling for input mismatch
        catch (Exception e) {
          {
            productDetails.clear(); // Clearing the array on incorrect input to make sure incomplete data is not added.
            System.out.println("\nINCORRECT DATA ENTERED!!! Please restart\n\n");
          }
        }

        return productDetails.toString();
      } else if (user_entry == 3) {
        System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println(" Apologies! Adding a Keyboard is Not Supported on the Database version of the Application");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

//        try {
//          System.out.println("\nPlease enter an Item Number (e.g. 3001) :");
//          int itemNumber = user_input_digits.nextInt();
//          productDetails.add(itemNumber);
//
//          System.out.println("\nPlease enter the Brand (e.g. Casio) :");
//          String brand = user_input_text.nextLine();
//          productDetails.add(brand);
//
//          System.out.println("\nPlease enter the Model (e.g. CDP-130) :");
//          String model = user_input_text.nextLine();
//          productDetails.add(model);
//
//          System.out.println("\nPlease enter a Price (e.g. 299) :");
//          float price = user_input_digits.nextFloat();
//          productDetails.add(price);
//
//          System.out.println("\nPlease enter the Number of Keys (e.g. 88) :");
//          int numOfKeys = user_input_digits.nextInt();
//          productDetails.add(numOfKeys);
//
//          System.out.println("\nPlease enter the Stock in Hand (e.g. 10) :");
//          int stock = user_input_digits.nextInt();
//          productDetails.add(stock);
//
//          System.out.println("Thank you for all the details");
//
//          // As the user selected 3, initialize Keyboard and then call the addProduct method
//          Keyboard kb1 = new Keyboard(itemNumber, brand, model, price, stock);
//
//          kb1.addProduct(itemNumber, brand, model, price, numOfKeys, stock);
//        }
//        // Exception handling for input mismatch
//        catch (Exception e) {
//          {
//            productDetails.clear(); // Clearing the array on incorrect input to make sure incomplete data is not added.
//            System.out.println("\nINCORRECT DATA ENTERED!!! Please restart\n\n");
//          }
//        }
//        return productDetails.toString();
      }
    }
  }
}