/**
 * CS-622
 * Product.java
 * Purpose: This is an abstract class that needs to be implemented
 * by any class that is used for adding a new product to the system.
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

// Abstract class that should used by all types of Products
public abstract class Product {

  private int itemNumber;
  private String brand;
  private String model;
  private float price;
  private int stockInHand;

  public abstract void addProduct();

  public Product(int itemNumber, String brand, String model, float price, int stockInHand) {
    this.itemNumber = itemNumber;
    this.brand = brand;
    this.model = model;
    this.price = price;
    this.stockInHand = stockInHand;
  }

  // Getter Setter for fields if required
  public int getItemNumber() {
    return itemNumber;
  }

  public void setItemNumber(int itemNumber) {
    this.itemNumber = itemNumber;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

  public int getStockInHand() {
    return stockInHand;
  }

  public void setStockInHand(int stockInHand) {
    this.stockInHand = stockInHand;
  }
}