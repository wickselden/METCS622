/**
 * CS-622
 * Keyboard.java
 * Purpose: This class extends the Product class and is used for adding a Keyboard to the system.
 *
 * @author Elden Wicks
 */

package com.Euphony.product;

public class Keyboard extends Product {

  public Keyboard(int itemNumber, String brand, String model, float price, int stockInHand) {
    super(itemNumber, brand, model, price, stockInHand);
  }

  @Override
  public void addProduct() {
    System.out.println("Adding Keyboard");
  }

  public String addProduct(int itemNumber, String brand, String model, float price, int numOfKeys, int stockInHand) {

    String message = String.format("Product details are - \n" +
            "Item number - %d, \nBrand - %s, \nModel - %s, \nPrice - %.2f, \nNum of Keys - %d, \nStock - %d",
        itemNumber, brand, model, price, numOfKeys, stockInHand);
    System.out.println(message);

    displaySuccessMessage();

    return message;

  }

  public String displaySuccessMessage() {
    String message = ("\nKeyboard has been added!");
    System.out.println(message);
    return (message);
  }
}