/**
 * CS-622
 * DbDataWriter.java
 * Purpose: This file is used to write data to the Derby Database
 * Based on the arguments received, the class picks table to write to
 * i.e. Products or Users table.
 * If also generates an ID for the user or product by using the current timestamp.
 * The class also validates if there was data entered before adding a new row to the CSV file
 * and does not add blank rows to the Database.
 * Please read inline comments for more information.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.*;

public class DbDataWriter {

  public String dbDataWriter(String data, String userOrProduct) throws ClassNotFoundException {

    // If the data length is > 2, then we can assume that data got pushed to the array as the [ ] make up the size of 2.
    // The [ ] is from the opening and closing square brackets of the array that is returned as string.
    if (data.length() > 2) {
      try {

        //Registering the driver
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        //Getting the Connection object
        String URL = "jdbc:derby:euphonydb";
        Connection conn = DriverManager.getConnection(URL);

        System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        long currentTime = (timestamp.getTime());             // Generate a long number
        String newIdStr = String.valueOf(currentTime);        // Convert to String to convert to int
        int newId = Integer.parseInt(newIdStr.substring(5));  // Convert to int

        //Creating the Statement object
        Statement stmt = conn.createStatement();

        String[] dataArray;
        // Remove the opening and closing square bracket as well as space after the commas
        data = data.substring(1, data.length() - 1).replace(", ", ",");
        //Split string with comma into a new array
        dataArray = data.split(",");

        // If argument received is "Product", then execute this
        if (userOrProduct.equals("Product")) {
          System.out.println("Running Insert Into Products\n");
          String insertQuery = String.format("INSERT INTO Products (Id, Item_Number, Brand, Model, Price, " +
                  "KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
                  "VALUES (%d, %d, '%s', '%s', %.2f, %d, %d, '%s', '%s', '%s', '%s', '%s' )",
              newId, Integer.parseInt(dataArray[0]), dataArray[1], dataArray[2], Float.parseFloat(dataArray[3]),
              Integer.parseInt(dataArray[4]), Integer.parseInt(dataArray[5]), dataArray[6],
              dataArray[7], dataArray[8], dataArray[9], dataArray[10]);
          stmt.execute(insertQuery);
        }

        // If argument received is "User", then execute this
        if (userOrProduct.equals("User")) {
          // If the first element is "Buyer" then execute this
          if (dataArray[0].equals("Buyer")) {
            System.out.println("Running Insert Buyer Into Users table\n");
            String insertQuery = String.format("INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
                    "VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %s)",
                newId, dataArray[0], dataArray[1], dataArray[2], dataArray[3], dataArray[4], dataArray[5], dataArray[6], null);
            System.out.println(insertQuery);
            stmt.execute(insertQuery);
          } else
          // If the first element is "Admin" then execute this
          {
            String insertQuery = String.format("INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
                    "VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
                newId, dataArray[0], dataArray[1], dataArray[2], dataArray[3], dataArray[4], dataArray[5], dataArray[6], dataArray[7]);
            System.out.println(insertQuery);
            stmt.execute(insertQuery);
          }
        }
        conn.close();
        System.out.println("Database Connection Closed!");
        System.out.println("----------------------------------------------------\n");
      }
      //  Exception handling for any I/O issues
      catch (SQLException e) {
        System.out.println(e);
        e.printStackTrace();
      }
    } else // If the data size is just 2, then there was no data written to it due to some error.
    {
      System.out.println("No data added as there was an error in you entry.");
    }
    return data;
  }
}