/**
 * CS-622
 * ViewProductsAndUsers.java
 * This class is displays all the data from the Products, Users and Orders tables
 * It is not actively used in the product, but just used to take a quick look at all the data in the database!
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ViewAllDbData {
  public void viewAllDbData() throws Exception {

    //Registering the driver
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Select From
    System.out.println("Fetching and Displaying Data from Products table\n".toUpperCase());
    String query5 = "SELECT * FROM Products ";
    ResultSet rs = stmt.executeQuery(query5);

    while (rs.next()) {
      System.out.println(rs.getString(1) + ", " +
          rs.getString(2) + ", " +
          rs.getString(3) + ", " +
          rs.getString(4) + ", " +
          rs.getString(5) + ", " +
          rs.getString(6) + ", " +
          rs.getString(7) + ", " +
          rs.getString(8) + ", " +
          rs.getString(9) + ", " +
          rs.getString(10) + ", " +
          rs.getString(11) + ", " +
          rs.getString(12)
      );
    }
    System.out.println("----------------------------------------------------");

    System.out.println("\nFetching and Displaying Data from Users table\n".toUpperCase());
    String query6 = "SELECT * FROM Users ";
    rs = stmt.executeQuery(query6);

    while (rs.next()) {
      System.out.println(rs.getString(1) + ", " +
          rs.getString(2) + ", " +
          rs.getString(3) + ", " +
          rs.getString(4) + ", " +
          rs.getString(5) + ", " +
          rs.getString(6) + ", " +
          rs.getString(7) + ", " +
          rs.getString(8) + ", " +
          rs.getString(9)
      );
    }
    System.out.println("----------------------------------------------------");

    System.out.println("\nFetching and Displaying Data from Orders table\n".toUpperCase());
    String query7 = "SELECT * FROM Orders ";
    rs = stmt.executeQuery(query7);

    while (rs.next()) {
      System.out.println(rs.getString(1) + ", " +
          rs.getString(2) + ", " +
          rs.getString(3) + ", " +
          rs.getString(4)
      );
    }
    conn.close();
    System.out.println("----------------------------------------------------");
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}