/**
 * CS-622
 * CreateTables.java
 * This class creates 'euphonydb' database and
 * also creates the Products, Users and Orders tables in the euphonydb
 * If these are already created and if data already exists, then it
 * throws the appropriate exceptions and continues with the program without halting it.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.*;

public class CreateTables {
  public void createTables() throws Exception {
    Connection conn = null;
    Statement stmt;

    //Registering the driver
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb;create=true";
    try {
      conn = DriverManager.getConnection(URL);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    System.out.println("Creating database -> " + URL.substring(11) + "\n");

    //Creating the Statement object
    stmt = conn.createStatement();

    try {
      //Creating the Products table
      String query1 = "CREATE TABLE Products( "
          + "Id INT NOT NULL, "
          + "Item_Number INT NOT NULL, "
          + "Brand VARCHAR(255) NOT NULL, "
          + "Model VARCHAR(255) NOT NULL, "
          + "Price NUMERIC, "
          + "KeyString NUMERIC, "
          + "Stock INT NOT NULL, "
          + "RhLh VARCHAR(255), "
          + "Attribute1 VARCHAR(255), "
          + "Attribute2 VARCHAR(255), "
          + "Attribute3 VARCHAR(255), "
          + "Attribute4 VARCHAR(255), "
          + "PRIMARY KEY (Id))";
      System.out.println("Running Create Table Products\n");
      stmt.execute(query1);
      System.out.println("Products Table created\n");
      System.out.println("--------------------------\n");
    } catch (SQLException e){
      System.out.println(("Table already created or some other issue encountered\n" + e));
      System.out.println("------------------------------------------------------\n");
    }

    //Creating the Users table
    try {
      String query2 = "CREATE TABLE Users( "
          + "Id INT NOT NULL, "
          + "Role VARCHAR(255) NOT NULL, "
          + "FirstName VARCHAR(255) NOT NULL, "
          + "LastName VARCHAR(255) NOT NULL, "
          + "Username VARCHAR(255) NOT NULL, "
          + "Password VARCHAR(255) NOT NULL, "
          + "Contact VARCHAR(255) NOT NULL, "
          + "Attribute1 VARCHAR(255), "
          + "Attribute2 VARCHAR(255), "
          + "PRIMARY KEY (Id))";
      System.out.println("Running Create Table Users\n");
      stmt.execute(query2);
      System.out.println("Users Table created");
      System.out.println("--------------------------\n");
    } catch (SQLException e){
      System.out.println(("Table already created or some other issue encountered\n" + e));
      System.out.println("------------------------------------------------------\n");
    }

    try {
      // Creating the Orders table for Multiple Table Requirement in Assignment 05 (Req. # 5.5.5)
      String query3 = "CREATE TABLE Orders( "
          + "OrderId INT NOT NULL, "
          + "OrderMonth INT NOT NULL, "
          + "UserId INT NOT NULL, "
          + "ProdId INT NOT NULL, "
          + "FOREIGN KEY (UserId) references Users(Id), "
          + "FOREIGN KEY (ProdId) references Products(Id), "
          + "PRIMARY KEY (OrderId))";
      System.out.println("Running Create Table Orders\n");
      stmt.execute(query3);
      System.out.println("Orders Table created");
      System.out.println("--------------------------\n");
    } catch (SQLException e){
      System.out.println(("Table already created or some other issue encountered\n" + e));
      System.out.println("------------------------------------\n");
    }

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}