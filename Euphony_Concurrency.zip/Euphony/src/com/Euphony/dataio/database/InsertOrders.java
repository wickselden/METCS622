/**
 * CS-622
 * InsertOrders.java
 * This class is used to enter data into the Orders table.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertOrders {
  public void insertOrders() throws Exception {
    //Registering the driver
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Insert Into Orders
    System.out.println("Running Insert Into Orders\n");


    String query2 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880001,1,2000000003,1000000001)";
    String query3 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880002,3,2000000003,1000000006) ";
    String query4 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880003,4,2000000006,1000000004) ";
    String query5 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880004,8,2000000006,1000000003) ";
    String query6 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880005,12,2000000006,1000000002) ";
    String query7 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880006,10,2000000003,1000000004)";
    String query8 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880007,7,2000000007,1000000005) ";
    String query9 = "INSERT INTO Orders (OrderId, OrderMonth, UserId, ProdId) VALUES (8880008,2,2000000007,1000000006)";

    try {
      stmt.execute(query2);
      stmt.execute(query3);
      stmt.execute(query4);
      stmt.execute(query5);
      stmt.execute(query6);
      stmt.execute(query7);
      stmt.execute(query8);
      stmt.execute(query9);

      System.out.println("Done Inserting Data Into Orders Table");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      System.out.println(("Data already inserted.\n" + e));
      System.out.println("------------------------------------------------------\n");
    }

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}