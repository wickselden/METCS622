/**
 * CS-622
 * DatabaseCreation.java
 * This class is is used to initialize the database creation, data insertion and data viewing classes.
 * This should be used only for testing the database creation,
 * Products, Users and Orders table creation, data insertion into these tables
 * and viewing all the data in the Products, Users and Orders tables.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

public class DatabaseCreation {

  public void createDatabase() throws Exception {
//  Create Database
    CreateTables createTables = new CreateTables();
    createTables.createTables();

//  Insert data into the Products table
    InsertProducts insertProducts = new InsertProducts();
    insertProducts.insertProducts();

//  Insert data into the Users table
    InsertUsers insertUsers = new InsertUsers();
    insertUsers.insertUsers();

//  Insert data into the Orders table
    InsertOrders insertOrders = new InsertOrders();
    insertOrders.insertOrders();

//  View all data from the Products and Users tables
    ViewAllDbData viewAllDbData = new ViewAllDbData();
    viewAllDbData.viewAllDbData();
  }
}