/**
 * CS-622
 * InsertUsers.java
 * This class is used to enter data into the Users table.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertUsers {
  public void insertUsers() throws Exception {
    //Registering the driver
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Insert Into
    System.out.println("Running Insert Into Users\n");

    String query2 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000001,'Admin','Elden','Wicks','eldenwicks','ewicksPa$$w0rd','6462900888','2/2/2020','Administrator') ";
    String query3 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000002,'Admin','Deeps','Chauhan','eepshikha','d33pPassw0rd','6462877777','2/11/2020','Operations') ";
    String query4 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000003,'Buyer','Ryan','Rogers','ryanwicks','ryanPwd!@#','ryanwicks@gmail.com','75 Page Road Bedford', '') ";
    String query5 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000004,'Admin','Chetan','Adiverekar','cadevere','cadPWD123','6462900334','1/2/2020','Manager') ";
    String query6 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000005,'Admin','Sonal','Adiverekar','csokar','$0Passw0rd','6462877777','2/11/2020','Support') ";
    String query7 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000006,'Buyer','Kabir','Khan','kkhan','kK@&!R!@#','kabirkhan@aol.com','36 Cambridge Road Woburn', '') ";
    String query8 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000007,'Buyer','Rafa','Nadal','vamos','RN@d@!','rafa@nadal.com','1 Madrid Road Catalonia', '') ";
    String query9 = "INSERT INTO Users (Id, Role, FirstName, LastName, Username, Password, Contact, Attribute1, Attribute2) " +
        "VALUES (2000000008,'Buyer','Rohit','Shetty','rohitshetty','r$h#tty','rohit@bolly.com','36 Shivaji Road Mumbai', '') ";

    try {
      stmt.execute(query2);
      stmt.execute(query3);
      stmt.execute(query4);
      stmt.execute(query5);
      stmt.execute(query6);
      stmt.execute(query7);
      stmt.execute(query8);
      stmt.execute(query9);


      System.out.println("Done Inserting Data Into Users");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      System.out.println(("Data already inserted.\n" + e));
      System.out.println("------------------------------------------------------\n");
    }

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}