/**
 * CS-622
 * InsertProducts.java
 * This class is used to enter data into the Products table.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertProducts {
  public void insertProducts() throws Exception {
    //Registering the driver
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);

    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

    //Creating the Statement object
    Statement stmt = conn.createStatement();

    //Executing Insert Into
    System.out.println("Running Insert Into Products\n");

    String query2 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000001, 1001, 'Gibson', 'G-1001', 1200, 5, 0,'RH', 'Rosewood', 'This is a good Gibson guitar', 'Maple', 'Fibreglass') ";
    String query3 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000002, 2001, 'Fender', 'F-2001', 900, 3, 0, 'LH', 'Aluminum', 'This is an excellent left handed Fender guitar', 'Stainless Steel', 'Advanced') ";
    String query4 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000003, 3001, 'Ricken', 'R-1001', 1200, 6, 5, 'RH', 'Maple', 'Good Rickenbacker', 'Teak', 'Basic') ";
    String query5 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000004, 4001, 'Gibson', 'G-1002', 599, 6, 12,'RH', 'Rosewood', 'This is a great Gibson guitar', 'Maple', 'Metal') ";
    String query6 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000005, 5001, 'Fender', 'F-2002', 1900, 3, 5, 'RH', 'Steel', 'This is an excellent right handed Fender guitar', 'Plastic', 'Advanced') ";
    String query7 = "INSERT INTO Products (Id, Item_Number, Brand, Model, Price, KeyString, Stock, RhLh, Attribute1, Attribute2, Attribute3, Attribute4) " +
        "VALUES (1000000006, 6001, 'Ricken', 'R-1002', 22000, 6, 2, 'RH', 'Copper', 'Great and Expensive Rickenbacker', 'Bamboo', 'Advanced') ";

    try {
      stmt.execute(query2);
      stmt.execute(query3);
      stmt.execute(query4);
      stmt.execute(query5);
      stmt.execute(query6);
      stmt.execute(query7);

      System.out.println("Done Inserting Data Into Products");
      System.out.println("--------------------------\n");
    } catch (SQLException e) {
      System.out.println(("Data already inserted.\n" + e));
      System.out.println("------------------------------------------------------\n");
    }

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}