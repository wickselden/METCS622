/**
 * CS-622
 * DataReader.java
 *
 * Purpose: This file is used to read the data from the CSV Files.
 * It reads String, int and float data from the CSV and returns it as a String[], Integer[] or Float[].
 * This class receives the filename as well as the csv column number to be read, from the class calling it.
 * It then reads the CSV until there are no lines left to read.
 * Then it splits the row data using commas and returns it as the required Array.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.csvFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

// This class reads data from a csv file at the given location
// and provides the required details requested
public class DataReader {

  public Integer[] readIntData(String fileToRead, int fieldNum) {
    ArrayList<Integer> idDetails = new ArrayList<>();
    try {
      BufferedReader csvReader = new BufferedReader(new FileReader(fileToRead));
      String row;
      while ((row = csvReader.readLine()) != null) {
        // This is to ignore the blank lines
        if (row.length() > 0) {
          String[] line = row.split(","); // This is to ignore the blank lines
          int id = Integer.parseInt(line[fieldNum]);
          idDetails.add(id);
        }
      }
      csvReader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return idDetails.toArray(new Integer[0]);
  }

  public String[] readStringData(String fileToRead, int fieldNum) {
    ArrayList csvData = new ArrayList();
    try {
      BufferedReader csvReader = new BufferedReader(new FileReader(fileToRead));
      String row;
      while ((row = csvReader.readLine()) != null) {
        if (row.length() > 0) {                   // This is to ignore the blank lines
          String[] line = row.split(",");
          csvData.add((line[fieldNum]).trim());  //  Get the appropriate field from the CSV file using field
        }
      }
      csvReader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return (String[]) csvData.toArray(new String[0]);
  }

  public Float[] readFloatData(String fileToRead, int fieldNum) {
    ArrayList<Float> floatData = new ArrayList();
    try {
      BufferedReader csvReader = new BufferedReader(new FileReader(fileToRead));
      String row;
      while ((row = csvReader.readLine()) != null) {
        if (row.length() > 0) {                       // This is to ignore the blank lines
          String[] line = row.split(",");
          float flt = Float.parseFloat(line[fieldNum]);
          floatData.add(flt);
        }
      }
      csvReader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return floatData.toArray(new Float[0]);
  }
}