/**
 * CS-622
 * DataWriter.java
 * Purpose: This file is used to write data to CSV Files.
 * Based on the argument received, the class picks the file which it needs to write to
 * i.e. product_data.csv or user_data.csv.
 * If also generates an ID for the user or product by using the current timestamp.
 * The class also validates if there was data entered before adding a new row to the CSV file
 * and does not add blank rows to the CSV.
 * Please read inline comments for more information.
 *
 * @author Elden Wicks
 */

package com.Euphony.dataio.csvFiles;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;


// This class writes data to a csv file at the given location
public class DataWriter {

  public String dataWriter(String data, String userOrProduct) {

    // This is to change the file name to user_data.csv if a User is being added
    // The default is set to product_data.csv for adding Product
    String filename = "./data/product_data.csv";
    if (userOrProduct.equals("User")) {
      filename = ("./data/user_data.csv");
    }

    // If the data length is > 2, then we can assume that data got pushed to the array as the [ ] make up the size of 2.
    // The [ ] is from the opening and closing square brackets of the array that is returned as string.
    if (data.length() > 2) {
      try {
        File file = new File(filename);
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);

        // Verify if file exists. Create if it doesn't.
        if (!file.exists()) {
          file.createNewFile();
        }

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        long currentTime = (timestamp.getTime());             // Generate a long number
        String newIdStr = String.valueOf(currentTime);        // Convert to String to convert to int
        int newId = Integer.parseInt(newIdStr.substring(4));  // Convert to int

        bw.write(newId + ",");   //    Write to CSV file as ID for new User
        // The Array returned as string includes the opening and closing square brackets. This is to get rid of them.
        System.out.println(data);
        bw.write(data.substring(1, data.length() - 1).replace(", ", ",")); // Added the replace to remove the spaces in between the comma separated values
        bw.write(System.lineSeparator());   // Add a line break after the data has been entered
        bw.close();
        System.out.println(data);
      }
      //  Exception handling for any I/O issues
      catch (
          IOException e) {
        e.printStackTrace();
      }
    } else // If the data size is just 2, then there was no data written to it due to some error.
    {
      System.out.println("No data added as there was an error in you entry.");
    }
    return data;
  }
}