/**
 * CS-622
 * OrderAndStockSimulator.java
 * Purpose: This class does the job of showing how ordering and stocking works without causing any concurrency issues.
 * It allows the order to be successful only if the product is available i.e. stock > 0.
 * It only allows the stocking to be successful if the product is not available i.e. stock == 0.
 * The users get an appropriate message for ordering and stocking success or failure.
 *
 * @author Elden Wicks
 */

package com.Euphony.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class OrderAndStockSimulator {
  public static void main(String[] args) throws Exception { //runReduceStock
    System.setOut(new AddDateToSysOut(System.out));
    int orders = 2;
    Integer[] prod_ids = new Integer[]{1001, 2001};

    ExecutorService ex = Executors.newCachedThreadPool(); // diff thread numbers
    for (int i = 1; i < orders; i++) {
      System.out.println("\n\n\n\nStocking Products - For Showing Concurrency".toUpperCase());
      ex.execute(new RunAddStock(prod_ids[0]));
      ex.execute(new RunAddStock(prod_ids[1]));
      System.out.println("\n\n\n\nRunning Order Product 1001 - SHOW SUCCESSFUL ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nRunning Order Product 1001 - SHOW SUCCESSFUL ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nRunning Order Product 2001 - SHOW SUCCESSFUL ORDER OF 2001");
      ex.execute(new RunReduceStock(prod_ids[1]));
      System.out.println("\n\n\n\nRunning Order Product 1001 - SHOW FAILED ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nStocking Product 1001 - SHOW SUCCESSFUL STOCKING OF 1001");
      ex.execute(new RunAddStock(prod_ids[0]));
      System.out.println("\n\n\n\nStocking Product 2001 - SHOW FAILED STOCKING OF 2001");
      ex.execute(new RunAddStock(prod_ids[1]));
      System.out.println("\n\n\n\nRunning Order Product 1001 4th - SHOW SUCCESSFUL ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nRunning Order Product 1001 5th - SHOW SUCCESSFUL ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nRunning Order Product 2001 2nd - SHOW SUCCESSFUL ORDER OF 2001");
      ex.execute(new RunReduceStock(prod_ids[1]));
      System.out.println("\n\n\n\nRunning Order Product 1001 6th - SHOW FAILED ORDER OF 1001");
      ex.execute(new RunReduceStock(prod_ids[0]));
      System.out.println("\n\n\n\nRunning Order Product 2001 3rd - SHOW FAILED ORDER OF 2001");
      ex.execute(new RunReduceStock(prod_ids[1]));
    }
    System.out.println("Running ex.shutdown");
    ex.shutdown();
    System.out.println("Running ex.awaitTermination");
    ex.awaitTermination(50, TimeUnit.MILLISECONDS);
  }
}

class RunReduceStock implements Runnable {
  ReduceStock reduceStock = new ReduceStock();

  public RunReduceStock(int prodIdToBuy) {
//    System.out.println("Started Running public First - Product ID received ->  " + prodIdToBuy + "\n");
    try {
      System.out.println("Running Reduce Stock for Product ID -> " + prodIdToBuy + "\n");
      reduceStock.reduceStock(prodIdToBuy);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void run() {
    System.out.println("This is the run() method" +
        " Thread ID = " + Thread.currentThread().getId() +
        " Thread Name = " + Thread.currentThread().getName());

  }
}

class RunAddStock implements Runnable {
  AddStock addStock = new AddStock();

  public RunAddStock(int prodIdToAdd) {
//    System.out.println("Started Running public First - Product ID received ->  " + prodIdToAdd + "\n");
    try {
      System.out.println("Running Add Stock for Product ID -> " + prodIdToAdd + "\n");
      addStock.addStock(prodIdToAdd);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void run() {
    System.out.println("This is the run() method" +
        " Thread ID = " + Thread.currentThread().getId() +
        " Thread Name = " + Thread.currentThread().getName());
  }
}

