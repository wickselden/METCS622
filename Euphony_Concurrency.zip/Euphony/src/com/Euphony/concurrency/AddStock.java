package com.Euphony.concurrency;

import java.sql.*;
import java.util.concurrent.TimeUnit;

public class AddStock {
  public void addStock(int prodid) throws Exception {
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);
    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");
    Statement stmt = conn.createStatement();
    String selectQuery1 = "SELECT STOCK FROM PRODUCTS WHERE ITEM_NUMBER  = " + prodid;
    String UpdateQuery1 = "UPDATE PRODUCTS SET STOCK = 2 WHERE ITEM_NUMBER  = " + prodid;

    TimeUnit.SECONDS.sleep(1);
    ResultSet rs1 = stmt.executeQuery(selectQuery1);
    rs1.next();
    int stock = Integer.parseInt(rs1.getString(1));
    System.out.println("Current Stock is -> " + stock);
    if (stock > 0) {
      System.out.println("STOCKING FAILED - Stocked already.\n");
    } else {
      try {
        System.out.println("Stocking product with ID -> \n" + prodid);
        stmt.execute(UpdateQuery1);
        System.out.println("STOCKING SUCCESSFUL\n");
        System.out.println("--------------------------\n");
      } catch (SQLException e) {
        System.out.println(("Could not Add Stock.\n" + e));
        System.out.println("------------------------------------------------------\n");
      }
    }
    TimeUnit.SECONDS.sleep(3);
    ResultSet rs3 = stmt.executeQuery(selectQuery1);
    rs3.next();
    int newstock = Integer.parseInt(rs3.getString(1));
    System.out.println("Stock after update is -> " + newstock);

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}

