package com.Euphony.concurrency;

import java.sql.*;
import java.util.concurrent.TimeUnit;

public class ReduceStock {
  public void reduceStock(int prodid) throws Exception {
    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    String URL = "jdbc:derby:euphonydb";
    Connection conn = DriverManager.getConnection(URL);
    System.out.println("Connecting to database -> " + URL.substring(11) + "\n");
    Statement stmt = conn.createStatement();
    String selectQuery1 = "SELECT STOCK FROM PRODUCTS WHERE ITEM_NUMBER  = " + prodid;
    String UpdateQuery1 = "UPDATE PRODUCTS SET STOCK = (STOCK-1) WHERE ITEM_NUMBER  = " + prodid;

    TimeUnit.SECONDS.sleep(1);
    ResultSet rs1 = stmt.executeQuery(selectQuery1);
    rs1.next();
    int stock = Integer.parseInt(rs1.getString(1));
    System.out.println("Current Stock is -> " + stock);
    if (stock <= 0) {
      System.out.println("NO STOCK LEFT. ORDERING FAILED.\n");
    } else {
      try {
        stmt.execute(UpdateQuery1);
        System.out.println("ORDERING SUCCESSFUL\n");
        System.out.println("Done Reducing Stock by 1\n");
        System.out.println("--------------------------\n");
      } catch (SQLException e) {
        System.out.println(("Could not Reduce Stock.\n" + e));
        System.out.println("------------------------------------------------------\n");
      }
    }
    TimeUnit.SECONDS.sleep(3);
    ResultSet rs3 = stmt.executeQuery(selectQuery1);
    rs3.next();
    int newstock = Integer.parseInt(rs3.getString(1));
    System.out.println("Stock after update is -> " + newstock);

    conn.close();
    System.out.println("Database Connection Closed!");
    System.out.println("----------------------------------------------------\n");
  }
}

