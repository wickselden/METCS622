/**
 * CS-622
 * AddUserWithUserInputs.java
 * Purpose: This class is used for requesting User data as input from the user.
 * This class displays the options for what type of User is to be added and
 * asks the user to enter the details for the user i.e. Administrator or Buyer.
 * After this it invokes the addUser method for displaying the appropriate message.
 * The same data input by the user is sent back to the DbDataWriter class (called from Main)
 * and this data is written to the Users table.
 *
 * @author Elden Wicks
 */

package com.Euphony.users;

import java.util.ArrayList;
import java.util.Scanner;

//This class takes the input from the users and adds the buyer or administrator details to the csv file.
public class AddUserWithUserInputs {

  public String collectUserInput() {

    // Created 2 scanner instances to capture String and int inputs as the scanner was the
    // newline after a string entered by the user as the next response
    Scanner user_input_text = new Scanner(System.in);
    Scanner user_input_digits = new Scanner(System.in);

    // ArrayLists for collecting the data from users
    ArrayList userDetails = new ArrayList();

    String message = ("\nPlease enter the following details".toUpperCase());

    while (true) {

      System.out.println("Please select the type of User you would like to add using the numbers 1 or 2:");
      System.out.println("1. Administrator\n" +
          "2. Buyer\n");

      int user_entry = user_input_digits.nextInt();

      if (user_entry == 1) {
        System.out.println(message);
        try {
          String type = "Admin";
          userDetails.add(type);

          System.out.println("\nPlease enter the First Name (e.g. Elden) :");
          String firstName = user_input_text.nextLine();
          userDetails.add(firstName);

          System.out.println("\nPlease enter the Last Name (e.g. Wicks) :");
          String lastName = user_input_text.nextLine();
          userDetails.add(lastName);

          System.out.println("\nPlease enter a Username (e.g. eldenwicks) :");
          String username = user_input_text.nextLine();
          userDetails.add(username);

          System.out.println("\nPlease enter the Password (e.g. myPassword) :");
          String password = user_input_text.nextLine();
          userDetails.add(password);

          System.out.println("\nPlease enter the Phone Number (e.g. 6462900888) :");
          String phoneNumber = user_input_text.nextLine();
          userDetails.add(phoneNumber);

          System.out.println("\nPlease enter the Date of Joining (e.g. 02/02/2020) :");
          String dateOfJoining = user_input_text.nextLine();
          userDetails.add(dateOfJoining);

          System.out.println("\nPlease enter the Designation (e.g. Manager) :");
          String designation = user_input_text.nextLine();
          userDetails.add(designation);

          System.out.println("Thank you for entering all the Administrator details");

          // As the user selected 1, initialize Add Administrator and then call the addUser method
          Administrator addAdmin = new Administrator("Admin", firstName, lastName, username, password, phoneNumber, dateOfJoining, designation);

          addAdmin.addUser("Admin", firstName, lastName, username, password, phoneNumber, dateOfJoining, designation);

        }
        // Exception handling for input mismatch
        catch (Exception e) {
          {
            userDetails.clear(); // Clearing the array on incorrect input to make sure incomplete data is not added.
            System.out.println("\nINCORRECT DATA ENTERED!!! Please restart\n\n");
          }
        }
        return userDetails.toString();
      } else if (user_entry == 2) {
        System.out.println(message);
        try {
          String type = "Buyer";
          userDetails.add(type);

          System.out.println("\nPlease enter the First Name (e.g. Ryan) :");
          String firstName = user_input_text.nextLine();
          if (firstName.length() == 0) {
            continue;
          }
          userDetails.add(firstName);

          System.out.println("\nPlease enter the Last Name (e.g. Wicks) :");
          String lastName = user_input_text.nextLine();
          userDetails.add(lastName);

          System.out.println("\nPlease enter a Username (e.g. ryanwicks) :");
          String username = user_input_text.nextLine();
          userDetails.add(username);

          System.out.println("\nPlease enter the Password (e.g. hisPassword) :");
          String password = user_input_text.nextLine();
          userDetails.add(password);

          System.out.println("\nPlease enter the Email ID (e.g. ryanwicks@gmail.com) :");
          String emailId = user_input_text.nextLine();
          userDetails.add(emailId);

          System.out.println("\nPlease enter the Address (e.g. 75 Page Road Bedford) :");
          String address = user_input_text.nextLine();
          userDetails.add(address);

          System.out.println("Thank you for entering all the Buyer details");

          // As the user selected 2, initialize Add Buyer and then call the addUser method
          Buyer addBuyer = new Buyer("Buyer", firstName, lastName, username, password, emailId, address, null);

          addBuyer.addUser("Buyer", firstName, lastName, username, password, emailId, address, null);

        }
        // Exception handling for input mismatch
        catch (Exception e) {
          {
            userDetails.clear(); // Clearing the array on incorrect input to make sure incomplete data is not added.
            System.out.println("\nINCORRECT DATA ENTERED!!! Please restart\n\n");
          }
        }
        return userDetails.toString();
      }
    }
  }
}