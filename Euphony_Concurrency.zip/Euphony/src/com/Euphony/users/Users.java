/**
 * CS-622
 * Users.java
 * Purpose: This is an abstract class that needs to be implemented
 * by any class that is used for adding a new users to the system.
 *
 * @author Elden Wicks
 */

package com.Euphony.users;

// Abstract class that should used by all types of Users
public abstract class Users {

  private String type;
  private String firstName;
  private String lastName;
  private String username;
  private String password;

  public abstract void addUser();

  public Users(String type, String firstName, String lastName, String username, String password) {
    this.type = type;
    this.firstName = firstName;
    this.lastName = lastName;
    this.username = username;
    this.password = password;
  }

  // Getter Setter for fields if required

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }
}