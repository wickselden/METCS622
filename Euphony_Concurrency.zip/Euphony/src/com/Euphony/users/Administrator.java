/**
 * CS-622
 * Administrator.java
 * Purpose: This class extends the Users class and is used for adding Administrators to the system.
 * It is also used for displaying a message once a Buyer has been added.
 *
 * @author Elden Wicks
 */

package com.Euphony.users;

public class Administrator extends Users {

  public Administrator(String type, String firstName, String lastName, String username, String password, String phoneNumber, String dateOfJoining, String designation) {
    super(type, firstName, lastName, username, password);
  }

  @Override
  public void addUser() {
    System.out.println("Adding Administrator");
  }

  public String addUser(String type, String firstName, String lastName, String username, String password, String phoneNumber, String dateOfJoining, String designation) {

    String message = String.format("Administrator details are - \n" +
            "Type - %s, \nFirst Name - %s, \nLast Name - %s, \nUsername - %s, \nPassword - %s, \nPhone Number - %s, " +
            "\nDate of Joining - %s, \nDesignation - %s\n",
        type, firstName, lastName, username, password, phoneNumber, dateOfJoining, designation);

    System.out.println(message);

    displaySuccessMessage();

    return message;

  }

  public String displaySuccessMessage() {
    String message = ("\nAdministrator has been added!\n\n");
    System.out.println(message);
    return (message);
  }

}