/**
 * CS-622
 * ValidateWithinOptions.java
 *
 * Purpose: This file is the user defined exception that throws a message from this file
 * when the user enters a number that is not within the required range.
 *
 * @author Elden Wicks
 */

package com.Euphony.exceptions;

public class ValidateWithinOptions extends NumberFormatException {
  String errorMessage;

  public ValidateWithinOptions(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  @Override
  public String toString() {
    return ("\nUser Defined Exception - Validate Within Options says - " + errorMessage);
  }
}