//package com.Euphony.concurrency;
//
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.TimeUnit;
//
//public class Concurrency123 {
//  public static void main(String[] args) throws Exception { //runReduceStock
//
////    Concurrency concurrency = new Concurrency();
////    concurrency.reduceStock(1001);
//    ExecutorService ex = Executors.newCachedThreadPool(); // diff thread numbers
////    ExecutorService ex = Executors.newFixedThreadPool(3); // diff thread numbers
//    ex.execute(new First(1001));
//    ex.execute(new First(2001));
////    ex.execute(new First(2, sharedcounter));
////    ex.execute(new First(3, sharedcounter));
//    ex.shutdown();
//    ex.awaitTermination(50, TimeUnit.MILLISECONDS);
//  }
//}
//
//class First implements Runnable {
//  Concurrency concurrency = new Concurrency();
//  public First(int i) {
//    System.out.println("Printing from inner First - Product ID ->  " + i);
//    try {
//      concurrency.reduceStock(i);
//    } catch (Exception e) {
//      e.printStackTrace();
//    }
//  }
//  public void run() {
//    System.out.println("Running First");
//  }
//}
//
//
