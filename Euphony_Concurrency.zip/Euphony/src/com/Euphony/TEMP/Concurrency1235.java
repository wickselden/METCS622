//package com.Euphony.concurrency;
//
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.TimeUnit;
//
//public class Concurrency123 {
//  public static void main(String[] args) throws Exception { //runReduceStock
//    System.setOut(new MyPrintStream(System.out));
//    int orders = 2;
//    Integer[] prod_ids = new Integer[]{1001, 2001, 3001};
//
//    ExecutorService ex = Executors.newCachedThreadPool(); // diff thread numbers
//    for (int i = 0; i < orders; i++) {
//      System.out.println("Running ex.execute first");
//      ex.execute(new First(1001));
//      System.out.println("Running ex.execute second");
//      ex.execute(new First(2001)); }
//    System.out.println("Running ex.shutdown");
//    ex.shutdown();
//    System.out.println("Running ex.awaitTermination");
//    ex.awaitTermination(50, TimeUnit.MILLISECONDS); }
//}
//
//class First implements Runnable {
//  Concurrency concurrency = new Concurrency();
//  public First(int prodIdToBuy) {
//    System.out.println("Started Running public First - Product ID received ->  " + prodIdToBuy + "\n");
//    try {
//      System.out.println("*************STARTED Sleeping in public First for 4 secs -> " + prodIdToBuy + "\n");
//      Thread.sleep(4000);
//      System.out.println("*************DONE SLEEPING for 4 SECONDS");
//      System.out.println("Running concurrency.reduceStock(i) -> " + prodIdToBuy + "\n");
//      concurrency.reduceStock(prodIdToBuy);
//    } catch (Exception e) {
//      e.printStackTrace(); }
//  }
//  public void run() {
//    try {
//      System.out.println("*************STARTED Sleeping in run() for 10 secs\n");
//      Thread.sleep(10000);
//      System.out.println("*************DONE SLEEPING for 10 SECONDS");
//    } catch (InterruptedException e) {
//      e.printStackTrace(); }
//    System.out.println("Last statement on the program\n"); }
//}
//
