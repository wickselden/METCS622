/**
 * CS-622
 * javaFx.java
 * Purpose: This is not a part of the Project and has only been created to try out the JavaFX features.
 * Please run this directly from here if you want to view the implementation.
 *
 * @author Elden Wicks
 */

package com.Euphony.javaFxDemoOnly;

import com.Euphony.dataio.csvFiles.DataReader;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.ArrayList;

public class javaFx extends Application {

  public void start(Stage scene) {
    scene.setTitle("Pick the data to view");
    Button brandButton = new Button("Show Brands");
    Button modelButton = new Button("Show Models");
    Button priceButton = new Button("Show Prices");
    Button userButton = new Button("Show Usernames");
    Button fnButton = new Button("Show First Names");
    Button lnButton = new Button("Show Last Names");
    Button closeButton = new Button("Close");
    GridPane gridPane = new GridPane();
    gridPane.setPadding(new Insets(10, 10, 10, 10));
    gridPane.setHgap(10);
    gridPane.setVgap(10);
    gridPane.setAlignment(Pos.TOP_CENTER);
    Label label = new Label();
    label.setFont(Font.font("Calibri", FontWeight.NORMAL, FontPosture.REGULAR, 15));
    label.setTextFill(Color.CHOCOLATE);

    EventHandler<ActionEvent> showBrand = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> prodDetails = new ArrayList<>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/product_data.csv", 2));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          prodDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(prodDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };
    EventHandler<ActionEvent> showModel = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> prodDetails = new ArrayList<String>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/product_data.csv", 3));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          prodDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(prodDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };

    EventHandler<ActionEvent> showPrices = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> prodDetails = new ArrayList<String>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/product_data.csv", 4));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          prodDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(prodDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };

    EventHandler<ActionEvent> showUsernames = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> userDetails = new ArrayList<>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/user_data.csv", 4));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          userDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(userDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };

    EventHandler<ActionEvent> showFirstNames = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> userDetails = new ArrayList<String>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/user_data.csv", 2));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          userDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(userDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };

    EventHandler<ActionEvent> showLastNames = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        ArrayList<String> userDetails = new ArrayList<String>();
        DataReader dr = new DataReader();
        String[] arr = (dr.readStringData("./data/user_data.csv", 3));
        int o = arr.length;
        for (int j = 0; j < o; j++) {
          userDetails.add("\n" + arr[j]);
        }
        String myText = String.valueOf(userDetails).replaceAll("[,\\[,\\]]", "");
        label.setText(myText);
      }
    };

    EventHandler<ActionEvent> closeStage = new EventHandler<ActionEvent>() {
      public void handle(ActionEvent e) {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
        System.out.println("Closing the pop-up!");
      }
    };

    brandButton.setOnAction(showBrand);
    modelButton.setOnAction(showModel);
    priceButton.setOnAction(showPrices);
    userButton.setOnAction(showUsernames);
    fnButton.setOnAction(showFirstNames);
    lnButton.setOnAction(showLastNames);
    closeButton.setOnAction(closeStage);

    gridPane.add(brandButton, 0, 0);
    gridPane.add(modelButton, 1, 0);
    gridPane.add(priceButton, 2, 0);
    gridPane.add(userButton, 3, 0);
    gridPane.add(fnButton, 4, 0);
    gridPane.add(lnButton, 5, 0);
    gridPane.add(closeButton, 6, 0);
    gridPane.add(label, 0, 1);

    Scene sc = new Scene(gridPane, 800, 800);
    scene.setScene(sc);
    scene.show();
  }
}