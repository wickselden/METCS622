/**
 * CS-622
 * PickWhichDbReport.java
 * Purpose: This class facilitates the selection of the report that the user would like to run.
 * This class calls the UserAndProductDbReports and OrdersDbReports class methods based on the users selections.
 * Users can enter 0 to go to the previous menu.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.dbReports;

import java.util.Scanner;

public class PickWhichDbReport {

  public static void pickWhichDbReport() throws ClassNotFoundException {

    while (true) {
      System.out.println(("\nWhat Database Report would you like to see?".toUpperCase()));
      Scanner user_input_digits = new Scanner(System.in);
      System.out.println("1. Show All Products\n" +
          "2. Show All Users\n" +
          "3. Show All Orders\n" +
          "4. Single Order Details\n" +
          "0. Go Back\n");
      int user_entry = user_input_digits.nextInt();

      /*
      Based on user selection select and display data from Users or Products table.
      If the user selects 0, then go to previous menu.
       */
      if (user_entry == 0) {
        System.out.println("Going to Previous Menu");
        break;
      }
      if (user_entry == 1) {
        UserAndProductDbReports.getUserAndProductDbReport("ProductsReport");
        continue;
      }
      if (user_entry == 2) {
        UserAndProductDbReports.getUserAndProductDbReport("UsersReport");
        continue;
      }
      if (user_entry == 3) {
        OrdersDbReports.getAllOrdersDbReport();
        continue;
      }
      if (user_entry == 4) {
        OrdersDbReports.getSingleOrderDetails();
      } else {
        System.out.println("\nPlease select the numbers listed or enter 0 to go back.\n");
      }
    }
  }
}