/**
 * CS-622
 * UserAndProductDbReports.java
 * Purpose: This class is used for retrieving data from the database and displaying it to the user.
 * It generates a report showing all users and all products.
 * This class also generates a CSV File Reports for Users and Products.
 * Please see in-line comments for method specific implementation details.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.dbReports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class UserAndProductDbReports {

  public static String getUserAndProductDbReport(String userRepOrProdRep) throws ClassNotFoundException {

    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn;
    ArrayList<String> results = new ArrayList<>();   // For capturing the retrieved data
    try {
      conn = DriverManager.getConnection(URL);

      System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

      //Creating the Statement object
      Statement stmt;
      stmt = conn.createStatement();

      // If the argument received is "ProductsReport", run this statement
      if (userRepOrProdRep.equals("ProductsReport")) {
        System.out.println("Displaying Products List Sorted by Price (High to Low)\n".toUpperCase());
        // Fetch data from Products table
        String selectQuery = "SELECT * FROM Products ORDER BY Price DESC, Brand";

        ResultSet rs = stmt.executeQuery(selectQuery);

        while (rs.next()) {
          // Add the resultset records to results
          results.add(rs.getString(1) + "\t" +
              rs.getString(2) + "\t" +
              rs.getString(3) + "\t" +
              rs.getString(4) + "\t" +
              rs.getString(5) + "\t" +
              rs.getString(6) + "\t" +
              rs.getString(7) + "\t" +
              rs.getString(8) + "\t" +
              rs.getString(9) + "\t" +
              rs.getString(10) + "\t" +
              rs.getString(11) + "\t" +
              rs.getString(12)
          );
        }
      } else { // If the argument received is "ProductsReport", run this statement
        System.out.println("Displaying Users List Sorted by Role and then by Last Name\n".toUpperCase());
        // Fetch data from Users table
        String selectQuery = "SELECT * FROM Users ORDER BY Role, LastName";

        ResultSet rs = stmt.executeQuery(selectQuery);
        while (rs.next()) {
          // Add the resultset records to results
          results.add(rs.getString(1) + "\t" +
              rs.getString(2) + "\t" +
              rs.getString(3) + "\t" +
              rs.getString(4) + "\t" +
              rs.getString(5) + "\t" +
              rs.getString(6) + "\t" +
              rs.getString(7) + "\t" +
              rs.getString(8) + "\t" +
              rs.getString(9)
          );
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Get timestamp for using in filename
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

    // Use timestamp in filename and also perform string manipulation to remove ":" and spaces with "_"
    String filename = ("./DatabaseReports/" + userRepOrProdRep + "_" + timestamp.toString().replace(":", "_").replace(" ", "_") + ".csv");

    // Convert ArrayList to String for displaying results on terminal
    String formattedResults = (results).toString();
    System.out.println((formattedResults).replace("[", "").replace("]", "").replace(", ", "\n"));

    try {
      // Create file and dump the data into the CSV File
      File file = new File(filename);
      FileWriter fw = new FileWriter(file, true);
      BufferedWriter bw = new BufferedWriter(fw);

      // Insert Header row in the CSV File based on what report is requested
      if (userRepOrProdRep == "ProductsReport") {
        bw.write("ProuctId,ItemNum,Brand,Model,Price,StringsOrKeys,Stock,Orientation,Attribute1,Attribute2,Attribute3,Attribute4\n");
      } else {
        bw.write("UserId,Role,FirstName,LastName,Username,Password,Contact,Attribute1,Attribute2\n");
      }
      //Perform replacements to get rid of unwanted characters and correct the output for a CSV file
      bw.write(formattedResults.replace("[", "")
          .replace("]", "")
          .replace(", ", "\n")
          .replace("\t", ","));
      bw.write(System.lineSeparator());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    System.out.println("Report saved at -> " + filename);
    System.out.println("----------------------------------------------------");

    return filename;  // Return filename with location
  }
}