/**
 * CS-622
 * OrdersDbReports.java
 * Purpose: This class is used for retrieving Orders data from the database and displaying it to the user.
 * It generates a report showing all orders along with the relevant details.
 * It also allows the user to select an Order Id and see the details just for that particular order.
 * This class also generates a CSV File Report showing All Orders.
 * Please see in-line comments for method specific implementation details.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.dbReports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class OrdersDbReports {

  public static String getAllOrdersDbReport() throws ClassNotFoundException {
    /*
    This method will display all the orders in the database along with the corresponding product belonging to the order
    and user details of the buyer that ordered the product.
    */

    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn;
    ArrayList<String> results = new ArrayList<>(); // For capturing the retrieved data
    try {
      conn = DriverManager.getConnection(URL);

      //Creating the Statement object
      Statement stmt;
      stmt = conn.createStatement();

      System.out.println("Displaying All Orders Sorted by First Name and then by Brand\n".toUpperCase());
      /* I have added the headers with tabs here to make the report look good with the current dataset output. */
      System.out.println("ORDER ID\tUSER ID\t\tFIRST NAME\tLAST NAME\tROLE\tPRODUCT ID\t\tBRAND\t\tMODEL\tPRICE\n");

      // Using an SQL JOIN Query to join the Orders, Users and Products table
      String selectQuery =
          "SELECT O.ORDERID, O.USERID, U.FIRSTNAME, U.LASTNAME, U.\"ROLE\" , O.PRODID,P.BRAND, P.MODEL, P.PRICE " +
              "FROM ORDERS O \n" +
              "JOIN USERS U ON O.USERID = U.ID \n" +
              "JOIN PRODUCTS P ON P.Id = O.PRODID \n" +
              "ORDER BY U.FIRSTNAME , P.BRAND ";

      ResultSet rs = stmt.executeQuery(selectQuery);

      while (rs.next()) {
        // Add the resultset records to results
        results.add(rs.getString(1) + "\t" +
            rs.getString(2) + "\t" +
            rs.getString(3) + "\t" +
            rs.getString(4) + "\t" +
            rs.getString(5) + "\t" +
            rs.getString(6) + "\t" +
            rs.getString(7) + "\t" +
            rs.getString(8) + "\t" +
            rs.getString(9)
        );
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }

    // Get timestamp for using in filename
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

    // Use timestamp in filename and also perform string manipulation to remove ":" and spaces with "_"
    String filename = ("./DatabaseReports/All_Orders_Report_" + timestamp.toString().replace(":", "_").replace(" ", "_") + ".csv");

    // Convert ArrayList to String for displaying results on terminal
    String formattedResults = (results).toString();
    System.out.println((formattedResults).replace("[", "").replace("]", "").replace(", ", "\n"));

    try {
      // Create file and dump the data into the CSV File
      File file = new File(filename);
      FileWriter fw = new FileWriter(file, true);
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write("OrderId,UserId,FirstName,LastName,Role,ProductId,Brand,Model,Price\n"); // Insert Header row in the CSV File
      //Perform replacements to get rid of unwanted characters and correct the output for a CSV file
      bw.write(formattedResults.replace("[", "")
          .replace("]", "")
          .replace(", ", "\n")
          .replace("\t", ","));
      bw.write(System.lineSeparator());
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    System.out.println("\nReport saved under DatabaseReports with name -> " + filename);
    System.out.println("----------------------------------------------------");
    return filename; // Return filename with location
  }

  public static void getSingleOrderDetails() throws ClassNotFoundException {
    /*
    This method will let the users select an Order Id from a list provided and show the details of that order to the user
    This method does not create a CSV Report file
    */

    // List all Order Ids using this method for the user to select from
    getAllOrderIds();

    // Take user input of Order ID to use in the SQL Query for fetching data
    Scanner user_input_digits = new Scanner(System.in);
    System.out.print("\nEnter an Order ID : ");
    int user_entry = user_input_digits.nextInt();

    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn;
    try {
      conn = DriverManager.getConnection(URL);

      //Creating the Statement object
      Statement stmt;
      stmt = conn.createStatement();

      System.out.println(("\nDisplaying Order details for Order ID -> " + user_entry + "\n").toUpperCase());

      // Using the Order Id requested from the user, fetch all the orders details
      // where the order id is equal the the one entered by the user
      String selectQuery =
          "SELECT O.ORDERID, O.USERID, U.FIRSTNAME, U.LASTNAME, U.\"ROLE\" , O.PRODID,P.BRAND, P.MODEL, P.PRICE FROM ORDERS O \n" +
              "JOIN USERS U ON O.USERID = U.ID \n" +
              "JOIN PRODUCTS P ON P.Id = O.PRODID \n " +
              "WHERE O.ORDERID = " + user_entry + " " +
              "ORDER BY U.USERNAME , P.BRAND ";

      ResultSet rs1 = stmt.executeQuery(selectQuery);

      // Get the size of the results
      int resutlSize = 0;
      while (rs1.next()) {
        resutlSize++;
      }
      // If there are no results, display the following message
      if (resutlSize == 0) {
        System.out.println("\nThere are no orders with the Order ID entered\n".toUpperCase());
      } else {
        // Display the headers only when there are records matching the requested OrderId
        // Added the headers with tabs here to make the report look good with the current dataset output
        System.out.println("ORDER ID\tUSER ID\tFIRST NAME\tLAST NAME\tROLE\tPRODUCT ID\tBRAND\tMODEL\tPRICE\n");
      }

      // Display the results on terminal
      ResultSet rs2 = stmt.executeQuery(selectQuery);
      while (rs2.next()) {
        System.out.println(rs2.getString(1) + "\t" +
            rs2.getString(2) + "\t" +
            rs2.getString(3) + "\t" +
            rs2.getString(4) + "\t" +
            rs2.getString(5) + "\t" +
            rs2.getString(6) + "\t" +
            rs2.getString(7) + "\t" +
            rs2.getString(8) + "\t" +
            rs2.getString(9)
        );
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    System.out.println("----------------------------------------------------");
  }

  private static void getAllOrderIds() throws ClassNotFoundException {
    /*
    This method is to retrieve all the Order IDs for being displayed to the user in the getSingleOrderDetails method.
    */

    Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    //Getting the Connection object
    String URL = "jdbc:derby:euphonydb";
    Connection conn;
    try {
      conn = DriverManager.getConnection(URL);

      System.out.println("Connecting to database -> " + URL.substring(11) + "\n");

      //Creating the Statement object
      Statement stmt;
      stmt = conn.createStatement();

      // Select only the OrderId column data from the Orders table
      String selectQuery = "SELECT OrderId FROM Orders ORDER BY OrderId";
      System.out.println("Enter an Order ID from the All Order IDs listed here - \n");
      ResultSet rs = stmt.executeQuery(selectQuery);

      // Print all Order IDs on the terminal
      while (rs.next()) {
        System.out.println(rs.getString(1)
        );
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    System.out.println("----------------------------------------------------");
  }
}