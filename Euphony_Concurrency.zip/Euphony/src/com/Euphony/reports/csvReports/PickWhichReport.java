/**
 * CS-622
 * PickWhichReport.java
 * Purpose: This class facilitates the selection of the data on which the user needs a report.
 * It provides the user an option to run different types of reports.
 * This class serves as a link to the CSV based, Database based and Stream/Lambda based reports.
 * Users can enter 0 to go to the previous menu.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.csvReports;

import com.Euphony.reports.dbReports.PickWhichDbReport;

import java.util.Scanner;

public class PickWhichReport {

  public static void pickWhichReport() throws ClassNotFoundException {

    while (true) {
      System.out.println(("\nWhat data would you like to create the report for?".toUpperCase()));
      Scanner user_input_digits = new Scanner(System.in);
      System.out.println("\nDATABASE REPORTS\n" +
          "1. DB Reports\n" +
          "\nSNAPSHOT REPORTS (Stream & Lambda)\n" +
          "2. Print Total Stock\n" +
          "3. Print Price of Most Expensive Product\n" +
          "4. Print Distinct Brands\n" +
          "5. Print Distinct Models\n" +
          "6. Print Total Price of Stocks\n" +
          "7. Print Purchase Price of Stocks\n" +
          "\nCSV BASED REPORTS\n" +
          "8. Users - CSV Reporting\n" +
          "9. Products - CSV Reporting\n" +
          "\n0. Go Back\n" +
          "\nEnter a number from above for the corresponding report\n");
      int user_entry = user_input_digits.nextInt();

      if (user_entry == 0) {
        System.out.println("Going to Previous Menu");
        break;
      }
      if (user_entry == 1) {
        PickWhichDbReport.pickWhichDbReport();
        continue;
      }
      if (user_entry == 2) {
        GetStatistics.getTotalProductStock();
        continue;
      }
      if (user_entry == 3) {
        GetStatistics.getMostExpensivePrice();
        continue;
      }
      if (user_entry == 4) {
        GetStatistics.getDistinctBrands();
        continue;
      }
      if (user_entry == 5) {
        GetStatistics.getDistinctModels();
        continue;
      }
      if (user_entry == 6) {
        GetStatistics.getTotalInventoryPrice();
        continue;
      }
      if (user_entry == 7) {
        GetStatistics.calculateCostOfInventory();
        continue;
      }
      if (user_entry == 8) {
        CsvReports.runUserReports();
        continue;
      }
      if (user_entry == 9) {
        CsvReports.runProductReports();
      } else {
        System.out.println("\nPlease select the numbers listed or enter 0 to go back.\n");
      }
    }
  }
}