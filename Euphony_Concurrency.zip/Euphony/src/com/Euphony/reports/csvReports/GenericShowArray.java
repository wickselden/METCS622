/**
 * CS-622
 * GenericShowArray.java
 * Purpose: This class is a generic class that takes input from
 * an Integer[] or a String[] and outputs the data for the Reports.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.csvReports;

import java.util.ArrayList;

public class GenericShowArray {
  public <T> void genericShowArray(T[] a) {
    ArrayList<T> output = new ArrayList();
    for (T elem : a) {
      System.out.println(elem);
      output.add(elem);
    }
    System.out.println("-----------------------");
  }
}