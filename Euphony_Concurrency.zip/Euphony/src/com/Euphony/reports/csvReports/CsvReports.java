/**
 * CS-622
 * CsvReports.java
 * Purpose: This class generates Reports using the GenericShowArray and DataReader class.
 * This class asks the user to select the desired field on which the report is to be generated.
 * Based on the user entry, it calls the appropriate methods to gather and print the data.
 * Please see in-line comments for method specific implementation details.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.reports.csvReports;

import com.Euphony.dataio.csvFiles.DataReader;

import java.util.Scanner;

public class CsvReports {

  //  Headers used by the printReportTitle method in generation of the Report Title
  static final String[] userHeaders = new String[]{"User IDs", "Roles", "First Names", "Last Names", "Usernames"};
  static final String[] productHeaders = new String[]{"Product ID", "Item Numbers", "Brands", "Models", "Prices", "Strings", "Stock"};

  public static void runUserReports() {

    GenericShowArray genericShowArray = new GenericShowArray();

    while (true) {
      System.out.println(("\nWhat User data would you like to create the report for?"));
      Scanner user_input_digits = new Scanner(System.in);
      System.out.println("1. User IDs\n" +
          "2. Role\n" +
          "3. First Name\n" +
          "4. Last Names\n" +
          "5. Usernames\n" +
          "0. Go Back\n");
      int user_entry = user_input_digits.nextInt();

      /*
        Based on the number selected, get data from the appropriate column of the csv file.
        Then convert this data using genericShowArray method.
        'user_entry -1' is used for reading the appropriate the columns in CSV.
      */
      if (user_entry == 0) {
        System.out.println("Going to Previous Menu");
        break;
      }
      if (user_entry == 1) {
        genericShowArray.genericShowArray(getUserIdsFromCSV(user_entry - 1));
        continue;
      }
      if (user_entry > 1 && user_entry < 6) {
        genericShowArray.genericShowArray(getStringDataFromUserCSV(user_entry - 1));
      } else {
        System.out.println("\nPlease select the numbers listed or enter 0 to go back.\n");
      }
    }
  }

  public static void runProductReports() {

    GenericShowArray genericShowArray = new GenericShowArray();

    while (true) {
      System.out.println(("\nWhat Product data would you like to create the report for?"));
      Scanner user_input_digits = new Scanner(System.in);
      System.out.println("1. Product IDs\n" +
          "2. Item Number\n" +
          "3. Brand\n" +
          "4. Model\n" +
          "5. Price\n" +
          "6. Stock\n" +
          "0. Go Back\n");
      int user_entry = user_input_digits.nextInt();

      /*
        Based on the number selected, get data from the appropriate column of the csv file.
        Then convert this data using genericShowArray method.
        'user_entry -1' is used for reading the appropriate the columns in CSV.
      */
      if (user_entry == 0) {
        System.out.println("Going to Previous Menu");
        break;
      }
      if (user_entry == 1 || user_entry == 2) {
        genericShowArray.genericShowArray(getIntDataFromProductCSV(user_entry - 1));
        continue;
      }
      if (user_entry == 3 || user_entry == 4) {
        genericShowArray.genericShowArray(getStringDataFromProductCSV(user_entry - 1));
        continue;
      }
      if (user_entry == 5) {
        genericShowArray.genericShowArray(getFloatDataFromProductCSV(user_entry - 1));
        continue;
      }
      if (user_entry == 6) {
        genericShowArray.genericShowArray(getIntDataFromProductCSV(user_entry));
      } else {
        System.out.println("\nPlease select the numbers listed or enter 0 to go back.\n");
      }
    }
  }

  /*
   * All these methods do the actual retrieval of data from the required CSV file using the DataReader class.
   * A method has been create for retrieving String, int and float data from the CSV files.
   * The printReportTitle method is used for printing the appropriate header of the Report.
   */

  public static Integer[] getUserIdsFromCSV(int fieldNum) {
    DataReader dataReader = new DataReader();
    printReportTitle(fieldNum, "user");
    Integer[] ids = dataReader.readIntData("./data/user_data.csv", fieldNum);
    return ids;
  }

  public static String[] getStringDataFromUserCSV(int fieldNum) {
    DataReader dataReader = new DataReader();
    printReportTitle(fieldNum, "user");
    String[] csvData = dataReader.readStringData("./data/user_data.csv", fieldNum);
    return csvData;
  }

  public static Integer[] getIntDataFromProductCSV(int fieldNum) {
    DataReader dataReader = new DataReader();
    printReportTitle(fieldNum, "product");
    Integer[] ids = dataReader.readIntData("./data/product_data.csv", fieldNum);
    return ids;
  }

  public static String[] getStringDataFromProductCSV(int fieldNum) {
    DataReader dataReader = new DataReader();
    printReportTitle(fieldNum, "product");
    String[] csvData = dataReader.readStringData("./data/product_data.csv", fieldNum);
    return csvData;
  }

  public static Float[] getFloatDataFromProductCSV(int fieldNum) {
    DataReader dataReader = new DataReader();
    printReportTitle(fieldNum, "product");
    Float[] floatData = dataReader.readFloatData("./data/product_data.csv", fieldNum);
    return floatData;
  }

  // This method for printing the Title of the Report
  private static void printReportTitle(int fieldNum, String item) {
    System.out.println("\n-----------------------");
    if (item.equals("product")) {
      System.out.println("PRINTING " + productHeaders[fieldNum].toUpperCase());
    } else {
      System.out.println("PRINTING " + userHeaders[fieldNum].toUpperCase());
    }
    System.out.println("-----------------------\n");
  }
}