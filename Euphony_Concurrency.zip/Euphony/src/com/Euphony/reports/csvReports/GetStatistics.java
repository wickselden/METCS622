/**
 * CS-622
 * GetStatistics.java
 * Purpose: This file uses Streams and lambdas for displaying the total stock that is available in the system.
 * This stock includes all type of instruments.
 * First it retrieves the Stock column data from the Product data.
 * Then it converts this data into a stream, which is then processed (i.e. addition) to get the total stock.
 * Please read in-line comments for specific methods for the logic applied.
 *
 * @author Elden Wicks
 */

package com.Euphony.reports.csvReports;

import java.util.stream.Stream;

public class GetStatistics {


  public static void getTotalProductStock() {
//  This method reads the stock column of the product_data.csv in an Integer Array
    Integer[] statsData = (CsvReports.getIntDataFromProductCSV(6));
//  Converts the retrieved data into a stream
    Stream<Integer> arrStream = Stream.of(statsData);
//  Uses the reduce method to add all the stocks= numbers retrieved and return the total stock
    System.out.println("There are a total of " +
        arrStream.reduce(0, (i, j) -> i + j) + " Products in stock");
    System.out.println("-----------------------\n");
  }

  public static void getMostExpensivePrice() {
//  This method reads the price column of the product_data.csv into a Float Array
    Float[] statsData = (CsvReports.getFloatDataFromProductCSV(4));
//  Converts the retrieved data into a stream
    Stream<Float> arrStream = Stream.of(statsData);
//  Compares the values in this column with each other and returns the biggest value using the max method
    System.out.printf("The most expensive product in stock is priced at $ %s/- %n", arrStream.max(Float::compare).get());
    System.out.println("-----------------------\n");
  }

  public static void getDistinctBrands() {
//  This method reads the Brand column of the product_data.csv in an String Array
    String[] statsData = (CsvReports.getStringDataFromProductCSV(2));
//  Converts the retrieved data into a stream
    Stream<String> arrStream1 = Stream.of(statsData);
//  Returns the count of only distinct values from this stream using the distinct and count methods.
    System.out.printf("Following are the %d Distinct Brands -> %n%n", arrStream1.distinct().count());
    Stream<String> arrStream2 = Stream.of(statsData);
//  Returns only the distinct values from this stream using the distinct method.
    arrStream2.distinct().forEach(System.out::println);
    System.out.println("-----------------------\n");
  }

  public static void getDistinctModels() {
//  This method reads the Models column of the product_data.csv in an String Array
    String[] statsData = (CsvReports.getStringDataFromProductCSV(3));
//  Converts the retrieved data into a stream
    Stream<String> arrStream1 = Stream.of(statsData);
//  Returns the count of only distinct values from this stream using the distinct and count methods.
    System.out.printf("Following are the %d Distinct Models -> %n%n", arrStream1.distinct().count());
    Stream<String> arrStream2 = Stream.of(statsData);
//  Returns only the distinct values from this stream using the distinct method.
    arrStream2.distinct().forEach(System.out::println);
    System.out.println("-----------------------\n");
  }

  public static void getTotalInventoryPrice() {
//  This method reads the Models column of the product_data.csv in an Float Array
    Float[] statsData = (CsvReports.getFloatDataFromProductCSV(4));
//  Converts the retrieved data into a stream
    Stream<Float> arrStream = Stream.of(statsData);
//  Uses the reduce method to add all the prices retrieved and return the total sum of prices
    System.out.println("The Total Price of all Products in Stock is " +
        arrStream.reduce((float) 0, (i, j) -> i + j));
    System.out.println("-----------------------\n");
  }

  public static void calculateCostOfInventory() {
//  This method reads the price column of the product_data.csv in an Float Array
    Float[] statsData = (CsvReports.getFloatDataFromProductCSV(4));
//  Converts the retrieved data into a stream
    Stream<Float> arrStream = Stream.of(statsData);
    System.out.println("The Cost/Purchase Price of all Products in Stock is " +
//  Calculates 80% of total price, as the store sells at 20% profit on purchase price
//  Using the map and reduce methods, it multiplies each value by 0.8 and then returns to total sum of all the prices
        arrStream.map(i -> i * (float) 0.8).reduce((float) 0, (i, j) -> i + j));
    System.out.println("-----------------------\n");
  }

  //  This class has been created to show JUnit Tests.
  public static Integer returnsForJUnit() {
    Integer[] statsData = (CsvReports.getIntDataFromProductCSV(6));
    Stream<Integer> arrStream = Stream.of(statsData);
    return arrStream.reduce(0, (i, j) -> i + j);
  }
}