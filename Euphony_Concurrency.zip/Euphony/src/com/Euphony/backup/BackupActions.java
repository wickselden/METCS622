/**
 * CS-622
 * BackupActions.java
 * Purpose: This class facilitates the selection of the action the user would like to take on the User and Product data backup.
 * Users can select to take the User or Product Backup or View the existing backups.
 * There are validations for catching incorrect number entry by the users and
 * a user can enter 0 to return to the previous menu.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.backup;

import java.util.Scanner;

public class BackupActions {

  public static void pickBackupAction() {

    while (true) {
      System.out.println(("\nPlease select a Backup Operation\n").toUpperCase());
      Scanner user_input_digits = new Scanner(System.in);
      System.out.println("1. Backup User Data\n" +
          "2. View User Backup\n" +
          "3. Backup Product Data\n" +
          "4. View Product Backup\n" +
          "0. Go Back\n");

      int user_entry = user_input_digits.nextInt();

      if (user_entry == 0) {
        System.out.println("Going to Previous Menu");
        break;
      }

      if (user_entry == 1 || user_entry == 3) {
        if (user_entry == 1) {
          DatFileWriter.backupData("User");
        } else DatFileWriter.backupData("Product");
        continue;
      }

      if (user_entry == 2 || user_entry == 4) {
        if (user_entry == 2) {
          DatFileReader.readBackupDataFile("User");
        } else DatFileReader.readBackupDataFile("Product");
      } else {
        System.out.println("\nPlease select the numbers listed or enter 0 to go back.\n");
      }
    }
  }
}