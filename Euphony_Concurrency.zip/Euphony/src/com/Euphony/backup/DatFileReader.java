/**
 * CS-622
 * DatFileReader.java
 *
 * Purpose: This class reads the data from the users_backup.dat or the product_backup.dat based on the users selection.
 * If the backup file does not exist, the system throws a message asking the user to take a backup.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.backup;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DatFileReader {
  public static void readBackupDataFile(String data) {
    System.out.println("\n--------------------------------------------------");
    System.out.println(("Reading and Printing " + data + " data from dat file.").toUpperCase());
    System.out.println("--------------------------------------------------\n");

    String backupFile = "users_backup.dat";
//  Change the backupFile name based on argument received
    if (data.equals("Product")) backupFile = "product_backup.dat";

    try (DataInputStream infile = new DataInputStream(new FileInputStream(backupFile))) {
//    Print out the data from the file
      while (true) System.out.printf("%-20s%n", infile.readUTF());
    } catch (EOFException ex) {
    } catch (FileNotFoundException fnf) {
      System.out.print("VIEW BACKUP ERROR \n-----------------\nBackup has not been created. Please backup the data before trying to view it.".toUpperCase());
    } catch (Exception ex) {
      System.out.print("Exception caught in main()");
      ex.printStackTrace();
    }
    System.out.println("\n-----------------------------------------\n");
  }
}