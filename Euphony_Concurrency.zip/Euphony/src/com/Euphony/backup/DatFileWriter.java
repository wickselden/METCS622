/**
 * CS-622
 * DatFileWriter.java
 *
 * Purpose: This class reads data from the Users or the Product CSV file.
 * It then creates (if file does not exist) and writes this data into the users_backup.dat or the product_backup.dat.
 *
 * @author Elden Wicks ewicks@bu.edu
 */

package com.Euphony.backup;

import java.io.*;

public class DatFileWriter {
  public static void backupData(String data) {
    String dataFile = "./data/user_data.csv";
    String backupFile = "users_backup.dat";
//  Change the values for the datFile and backupFile based on the argument received
    if (data.equals("Product")) {
      dataFile = "./data/product_data.csv";
      backupFile = "product_backup.dat";
    }

    try (DataOutputStream outfile = new DataOutputStream(new FileOutputStream(backupFile))) {
      BufferedReader csvReader = new BufferedReader(new FileReader(dataFile));
      String row;
//    Read file until the end of file
      while ((row = csvReader.readLine()) != null) {
//      Validate that the row has some data
        if (row.length() > 0) {
//        Write to the outfile
          outfile.writeUTF(row);
        }
      }
    } catch (EOFException ex) {
      System.out.print("EOF reached in infile");
    } catch (Exception ex) {
      System.out.print("Exception caught in main()");
      ex.printStackTrace();
    }
    System.out.println("\n-----------------------------------------");
    System.out.println(("Done Backing-up " + data + " data to dat file.").toUpperCase());
    System.out.println("-----------------------------------------\n");
  }
}